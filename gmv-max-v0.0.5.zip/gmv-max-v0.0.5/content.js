/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./extension/constants/regions.ts":
/*!****************************************!*\
  !*** ./extension/constants/regions.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BASE_URL: () => (/* binding */ BASE_URL),
/* harmony export */   LIVE_CAMPAIGNS: () => (/* binding */ LIVE_CAMPAIGNS),
/* harmony export */   REGION_CONFIG: () => (/* binding */ REGION_CONFIG)
/* harmony export */ });
const REGION_CONFIG = {
    US: {
        aadvid: "6860053951073484806",
        oec_seller_id: "7495275617887947202",
        bc_id: "7278556643061792769",
        utcOffset: 9, // UTC+09:00
    },
    ID: {
        aadvid: "7208105767293992962",
        oec_seller_id: "7494928748302076708",
        bc_id: "7208106862128939009",
        utcOffset: 7, // UTC+07:00
    },
    PH: {
        aadvid: "7265198676149075969",
        oec_seller_id: "7495168184921196786",
        bc_id: "7265198572054888449",
        utcOffset: 8, // UTC+08:00
    },
    MY: {
        aadvid: "7525257295555772423",
        oec_seller_id: "7496261644146150198",
        bc_id: "7525256178398674952",
        utcOffset: 8, // UTC+08:00
    },
};
const BASE_URL = "https://ads.tiktok.com/i18n/gmv-max/dashboard/product";
const LIVE_CAMPAIGNS = [
    { name: "SKIN1004MY(1st)", id: "1842021739590817" },
    { name: "skin1004my_official_250909", id: "1842771753445410" }
];


/***/ }),

/***/ "./extension/constants/storage.ts":
/*!****************************************!*\
  !*** ./extension/constants/storage.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   STORAGE_KEYS: () => (/* binding */ STORAGE_KEYS)
/* harmony export */ });
const STORAGE_KEYS = {
    CAMPAIGN_DATA: "gmv_max_campaign_data",
    CURRENT_INDEX: "gmv_max_current_index",
    COMPLETED_CAMPAIGNS: "gmv_max_completed_campaigns",
    AUTO_CLICK_ENABLED: "gmv_max_auto_click_enabled",
    LAST_UPLOAD_STATUS: "lastUploadStatus",
    UPLOAD_SUCCESS_STATUS: "gmv_max_upload_success_status",
    CAMPAIGN_REGIONS: "gmv_max_campaign_regions",
    CAMPAIGN_TYPES: "gmv_max_campaign_types",
    DATE_RANGE: "gmv_max_date_range",
};


/***/ }),

/***/ "./extension/utils/date-utils.ts":
/*!***************************************!*\
  !*** ./extension/utils/date-utils.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   regionDateToTimestamp: () => (/* binding */ regionDateToTimestamp)
/* harmony export */ });
/* harmony import */ var _constants_regions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/regions */ "./extension/constants/regions.ts");

/**
 * Convert region-specific date to timestamp
 */
function regionDateToTimestamp(region, year, month, day, hour = 0, minute = 0, second = 0) {
    const offset = _constants_regions__WEBPACK_IMPORTED_MODULE_0__.REGION_CONFIG[region].utcOffset;
    const utcDate = new Date(Date.UTC(year, month - 1, day, hour - offset, minute, second));
    return utcDate.getTime();
}


/***/ }),

/***/ "./extension/utils/url-builder.ts":
/*!****************************************!*\
  !*** ./extension/utils/url-builder.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildCampaignUrl: () => (/* binding */ buildCampaignUrl)
/* harmony export */ });
/* harmony import */ var _constants_regions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/regions */ "./extension/constants/regions.ts");

/**
 * Build campaign URL with region-specific parameters
 */
function buildCampaignUrl(region, campaignId, startTimestamp, endTimestamp, campaignType = "PRODUCT") {
    const config = _constants_regions__WEBPACK_IMPORTED_MODULE_0__.REGION_CONFIG[region];
    const baseUrl = campaignType === "LIVE"
        ? "https://ads.tiktok.com/i18n/gmv-max/dashboard/live"
        : _constants_regions__WEBPACK_IMPORTED_MODULE_0__.BASE_URL;
    const params = new URLSearchParams({
        aadvid: config.aadvid,
        oec_seller_id: config.oec_seller_id,
        bc_id: config.bc_id,
        type: campaignType.toLowerCase(),
        list_status: "delivery_ok",
        campaign_id: campaignId,
        campaign_start_date: startTimestamp.toString(),
        campaign_end_date: endTimestamp.toString(),
    });
    return `${baseUrl}?${params.toString()}`;
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!******************************!*\
  !*** ./extension/content.ts ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants/storage */ "./extension/constants/storage.ts");
/* harmony import */ var _utils_date_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/date-utils */ "./extension/utils/date-utils.ts");
/* harmony import */ var _utils_url_builder__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils/url-builder */ "./extension/utils/url-builder.ts");
/**
 * Content script for auto-clicking export button on TikTok Ads GMV Max dashboard
 * Runs on campaign pages and automatically clicks the export button when available
 * Also detects downloaded files and triggers upload to Google Drive
 */



const STORAGE_KEY = "gmv_max_auto_click_enabled";
const WORKFLOW_PAUSED_KEY = "gmv_max_workflow_paused";
const MAX_RETRY_ATTEMPTS = 10;
const RETRY_INTERVAL = 1000; // 1 second
const DOWNLOAD_DETECTION_DELAY = 3000; // Wait 3 seconds after clicking before checking downloads
const AUTO_NAVIGATION_DELAY = 2000; // Wait 2 seconds after upload success before auto-navigating to next campaign
// Deduplication: Track if we've already clicked to prevent duplicate uploads
let hasClickedExportButton = false;
let uploadInProgress = false;
// Auto-navigation control - load from localStorage, default state is paused
let isAutoNavigationPaused = true;
/**
 * Attempt to find and click the export button
 * Uses multiple selector strategies for robustness
 * Includes deduplication to prevent multiple clicks
 */
function findAndClickExportButton() {
    // Prevent duplicate clicks
    if (hasClickedExportButton) {
        console.log("[GMV Max Navigator] Export button already clicked, skipping");
        return true;
    }
    // Strategy 1: Use data-testid attribute (most reliable)
    const buttonByTestId = document.querySelector('button[data-testid="export-button-index-wN5QRr"]');
    if (buttonByTestId) {
        console.log("[GMV Max Navigator] Found export button by test ID");
        hasClickedExportButton = true;
        buttonByTestId.click();
        // Trigger download detection after clicking
        setTimeout(() => detectAndUploadDownloadedFile(), DOWNLOAD_DETECTION_DELAY);
        return true;
    }
    // Strategy 2: Use data-tea-click_for attribute
    const buttonByTeaClick = document.querySelector('button[data-tea-click_for="export_button_view_data_product"]');
    if (buttonByTeaClick) {
        console.log("[GMV Max Navigator] Found export button by tea-click attribute");
        hasClickedExportButton = true;
        buttonByTeaClick.click();
        // Trigger download detection after clicking
        setTimeout(() => detectAndUploadDownloadedFile(), DOWNLOAD_DETECTION_DELAY);
        return true;
    }
    // Strategy 3: Use data-tid attribute
    const buttonByTid = document.querySelector('button[data-tid="m4b_button"][data-uid*="exportbutton"]');
    if (buttonByTid) {
        console.log("[GMV Max Navigator] Found export button by tid attribute");
        hasClickedExportButton = true;
        buttonByTid.click();
        // Trigger download detection after clicking
        setTimeout(() => detectAndUploadDownloadedFile(), DOWNLOAD_DETECTION_DELAY);
        return true;
    }
    // Strategy 4: Look for button with launch icon SVG
    const buttons = document.querySelectorAll('button.theme-m4b-button');
    for (const button of buttons) {
        const svg = button.querySelector('svg.theme-arco-icon-launch');
        if (svg) {
            console.log("[GMV Max Navigator] Found export button by SVG icon");
            hasClickedExportButton = true;
            button.click();
            // Trigger download detection after clicking
            setTimeout(() => detectAndUploadDownloadedFile(), DOWNLOAD_DETECTION_DELAY);
            return true;
        }
    }
    return false;
}
/**
 * Extract campaign ID from current URL
 */
function getCampaignIdFromUrl() {
    const url = new URL(window.location.href);
    return url.searchParams.get("campaign_id");
}
/**
 * Get campaign name from localStorage using campaign ID
 */
async function getCampaignName(campaignId) {
    return new Promise((resolve) => {
        chrome.storage.local.get(["gmv_max_campaign_data"], (result) => {
            const campaigns = result.gmv_max_campaign_data || [];
            const campaign = campaigns.find((c) => c.id === campaignId);
            resolve(campaign ? campaign.name : null);
        });
    });
}
/**
 * Detect and upload the most recently downloaded file
 * Sends request to background script which has access to downloads API
 * Includes deduplication to prevent multiple uploads
 */
async function detectAndUploadDownloadedFile() {
    try {
        // Prevent duplicate uploads
        if (uploadInProgress) {
            console.log("[GMV Max Navigator] Upload already in progress, skipping");
            return;
        }
        uploadInProgress = true;
        console.log("[GMV Max Navigator] Detecting downloaded file...");
        // Get campaign info from URL
        const campaignId = getCampaignIdFromUrl();
        if (!campaignId) {
            console.warn("[GMV Max Navigator] No campaign ID found in URL");
            uploadInProgress = false;
            return;
        }
        const campaignName = await getCampaignName(campaignId);
        if (!campaignName) {
            console.warn("[GMV Max Navigator] No campaign name found for ID:", campaignId);
            uploadInProgress = false;
            return;
        }
        console.log("[GMV Max Navigator] Campaign info:", { campaignId, campaignName });
        // Send request to background script to handle download detection and upload
        console.log("[GMV Max Navigator] Requesting background script to check downloads...");
        chrome.runtime.sendMessage({
            type: "CHECK_AND_UPLOAD_DOWNLOAD",
            campaignName: campaignName,
            campaignId: campaignId,
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("[GMV Max Navigator] Error sending message to background:", chrome.runtime.lastError);
                uploadInProgress = false;
                return;
            }
            if (response === null || response === void 0 ? void 0 : response.success) {
                console.log("[GMV Max Navigator] Background script processing upload");
            }
            else {
                console.error("[GMV Max Navigator] Background script error:", response === null || response === void 0 ? void 0 : response.error);
            }
            // Reset flag after upload completes (with delay to ensure background processing finishes)
            setTimeout(() => {
                uploadInProgress = false;
            }, 5000);
        });
    }
    catch (error) {
        console.error("[GMV Max Navigator] Error in detectAndUploadDownloadedFile:", error);
        uploadInProgress = false;
    }
}
/**
 * Retry logic for finding and clicking the button
 * The button might not be immediately available when the page loads
 */
function attemptAutoClick(attempt = 1) {
    console.log(`[GMV Max Navigator] Attempt ${attempt}/${MAX_RETRY_ATTEMPTS} to find export button`);
    const clicked = findAndClickExportButton();
    if (clicked) {
        console.log("[GMV Max Navigator] Successfully clicked export button");
        return;
    }
    if (attempt < MAX_RETRY_ATTEMPTS) {
        setTimeout(() => attemptAutoClick(attempt + 1), RETRY_INTERVAL);
    }
    else {
        console.log("[GMV Max Navigator] Max retry attempts reached. Export button not found.");
    }
}
/**
 * Navigate to the previous uncompleted campaign
 */
async function goToPrevCampaign() {
    try {
        const result = await chrome.storage.local.get([
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_DATA,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CURRENT_INDEX,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.UPLOAD_SUCCESS_STATUS,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_REGIONS,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_TYPES,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.DATE_RANGE,
        ]);
        const campaigns = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_DATA] || [];
        const currentIndex = parseInt(result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CURRENT_INDEX] || "0", 10);
        const uploadSuccessStatus = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.UPLOAD_SUCCESS_STATUS] || {};
        const campaignRegions = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_REGIONS] || {};
        const campaignTypes = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_TYPES] || {};
        const dateRange = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.DATE_RANGE];
        if (campaigns.length === 0) {
            alert("No campaigns available");
            return;
        }
        if (!dateRange) {
            alert("Date range not configured. Please set date range in extension popup.");
            return;
        }
        // Find the previous uncompleted campaign
        let prevIndex = currentIndex - 1;
        let foundPrev = false;
        // Search backward from current position
        for (let i = prevIndex; i >= 0; i--) {
            const campaign = campaigns[i];
            const uploadStatus = uploadSuccessStatus[campaign.name];
            // Skip completed campaigns
            if (!uploadStatus || uploadStatus.status !== "success") {
                prevIndex = i;
                foundPrev = true;
                break;
            }
        }
        // If no uncompleted campaign found before, wrap around to end
        if (!foundPrev) {
            for (let i = campaigns.length - 1; i >= currentIndex; i--) {
                const campaign = campaigns[i];
                const uploadStatus = uploadSuccessStatus[campaign.name];
                if (!uploadStatus || uploadStatus.status !== "success") {
                    prevIndex = i;
                    foundPrev = true;
                    break;
                }
            }
        }
        if (!foundPrev) {
            alert("All campaigns completed! 🎉");
            return;
        }
        // Navigate to previous campaign with proper URL building
        const campaign = campaigns[prevIndex];
        const region = campaignRegions[campaign.id];
        if (!region) {
            alert(`Please select a region for campaign: ${campaign.name}`);
            return;
        }
        // Calculate timestamps based on region
        const startTimestamp = (0,_utils_date_utils__WEBPACK_IMPORTED_MODULE_1__.regionDateToTimestamp)(region, dateRange.startYear, dateRange.startMonth, dateRange.startDay);
        const endTimestamp = (0,_utils_date_utils__WEBPACK_IMPORTED_MODULE_1__.regionDateToTimestamp)(region, dateRange.endYear, dateRange.endMonth, dateRange.endDay);
        // Get campaign type (default to PRODUCT if not set)
        const campaignType = campaignTypes[campaign.id] || "PRODUCT";
        // Build the campaign URL
        const newUrl = (0,_utils_url_builder__WEBPACK_IMPORTED_MODULE_2__.buildCampaignUrl)(region, campaign.id, startTimestamp, endTimestamp, campaignType);
        // Update current index
        await chrome.storage.local.set({ [_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CURRENT_INDEX]: prevIndex.toString() });
        console.log(`[GMV Max Navigator] Navigating to previous campaign: ${campaign.name}`);
        window.location.href = newUrl;
    }
    catch (error) {
        console.error("[GMV Max Navigator] Error navigating to previous campaign:", error);
        alert("Failed to navigate to previous campaign");
    }
}
/**
 * Navigate to the first uncompleted campaign in the list
 */
async function goToFirstCampaign() {
    try {
        const result = await chrome.storage.local.get([
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_DATA,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.UPLOAD_SUCCESS_STATUS,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_REGIONS,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_TYPES,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.DATE_RANGE,
        ]);
        const campaigns = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_DATA] || [];
        const uploadSuccessStatus = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.UPLOAD_SUCCESS_STATUS] || {};
        const campaignRegions = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_REGIONS] || {};
        const campaignTypes = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_TYPES] || {};
        const dateRange = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.DATE_RANGE];
        if (campaigns.length === 0) {
            alert("No campaigns available");
            return;
        }
        if (!dateRange) {
            alert("Date range not configured. Please set date range in extension popup.");
            return;
        }
        // Find the first uncompleted campaign
        let firstIndex = -1;
        for (let i = 0; i < campaigns.length; i++) {
            const campaign = campaigns[i];
            const uploadStatus = uploadSuccessStatus[campaign.name];
            // Skip completed campaigns
            if (!uploadStatus || uploadStatus.status !== "success") {
                firstIndex = i;
                break;
            }
        }
        if (firstIndex === -1) {
            alert("All campaigns completed! 🎉");
            return;
        }
        // Navigate to first uncompleted campaign with proper URL building
        const campaign = campaigns[firstIndex];
        const region = campaignRegions[campaign.id];
        if (!region) {
            alert(`Please select a region for campaign: ${campaign.name}`);
            return;
        }
        // Calculate timestamps based on region
        const startTimestamp = (0,_utils_date_utils__WEBPACK_IMPORTED_MODULE_1__.regionDateToTimestamp)(region, dateRange.startYear, dateRange.startMonth, dateRange.startDay);
        const endTimestamp = (0,_utils_date_utils__WEBPACK_IMPORTED_MODULE_1__.regionDateToTimestamp)(region, dateRange.endYear, dateRange.endMonth, dateRange.endDay);
        // Get campaign type (default to PRODUCT if not set)
        const campaignType = campaignTypes[campaign.id] || "PRODUCT";
        // Build the campaign URL
        const newUrl = (0,_utils_url_builder__WEBPACK_IMPORTED_MODULE_2__.buildCampaignUrl)(region, campaign.id, startTimestamp, endTimestamp, campaignType);
        // Update current index
        await chrome.storage.local.set({ [_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CURRENT_INDEX]: firstIndex.toString() });
        console.log(`[GMV Max Navigator] Navigating to first campaign: ${campaign.name}`);
        window.location.href = newUrl;
    }
    catch (error) {
        console.error("[GMV Max Navigator] Error navigating to first campaign:", error);
        alert("Failed to navigate to first campaign");
    }
}
/**
 * Navigate to the next uncompleted campaign
 */
async function goToNextCampaign() {
    try {
        const result = await chrome.storage.local.get([
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_DATA,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CURRENT_INDEX,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.UPLOAD_SUCCESS_STATUS,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_REGIONS,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_TYPES,
            _constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.DATE_RANGE,
        ]);
        const campaigns = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_DATA] || [];
        const currentIndex = parseInt(result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CURRENT_INDEX] || "0", 10);
        const uploadSuccessStatus = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.UPLOAD_SUCCESS_STATUS] || {};
        const campaignRegions = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_REGIONS] || {};
        const campaignTypes = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CAMPAIGN_TYPES] || {};
        const dateRange = result[_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.DATE_RANGE];
        if (campaigns.length === 0) {
            alert("No campaigns available");
            return;
        }
        if (!dateRange) {
            alert("Date range not configured. Please set date range in extension popup.");
            return;
        }
        // Find the next uncompleted campaign
        let nextIndex = currentIndex + 1;
        let foundNext = false;
        // Search forward from current position
        for (let i = nextIndex; i < campaigns.length; i++) {
            const campaign = campaigns[i];
            const uploadStatus = uploadSuccessStatus[campaign.name];
            // Skip completed campaigns
            if (!uploadStatus || uploadStatus.status !== "success") {
                nextIndex = i;
                foundNext = true;
                break;
            }
        }
        // If no uncompleted campaign found ahead, wrap around to beginning
        if (!foundNext) {
            for (let i = 0; i <= currentIndex; i++) {
                const campaign = campaigns[i];
                const uploadStatus = uploadSuccessStatus[campaign.name];
                if (!uploadStatus || uploadStatus.status !== "success") {
                    nextIndex = i;
                    foundNext = true;
                    break;
                }
            }
        }
        if (!foundNext) {
            alert("All campaigns completed! 🎉");
            return;
        }
        // Navigate to next campaign with proper URL building
        const campaign = campaigns[nextIndex];
        const region = campaignRegions[campaign.id];
        if (!region) {
            alert(`Please select a region for campaign: ${campaign.name}`);
            return;
        }
        // Calculate timestamps based on region
        const startTimestamp = (0,_utils_date_utils__WEBPACK_IMPORTED_MODULE_1__.regionDateToTimestamp)(region, dateRange.startYear, dateRange.startMonth, dateRange.startDay);
        const endTimestamp = (0,_utils_date_utils__WEBPACK_IMPORTED_MODULE_1__.regionDateToTimestamp)(region, dateRange.endYear, dateRange.endMonth, dateRange.endDay);
        // Get campaign type (default to PRODUCT if not set)
        const campaignType = campaignTypes[campaign.id] || "PRODUCT";
        // Build the campaign URL
        const newUrl = (0,_utils_url_builder__WEBPACK_IMPORTED_MODULE_2__.buildCampaignUrl)(region, campaign.id, startTimestamp, endTimestamp, campaignType);
        // Update current index
        await chrome.storage.local.set({ [_constants_storage__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEYS.CURRENT_INDEX]: nextIndex.toString() });
        console.log(`[GMV Max Navigator] Navigating to next campaign: ${campaign.name}`);
        window.location.href = newUrl;
    }
    catch (error) {
        console.error("[GMV Max Navigator] Error navigating to next campaign:", error);
        alert("Failed to navigate to next campaign");
    }
}
/**
 * Update upload status toast with current status
 */
function updateUploadStatusToast(status, message) {
    const toast = document.getElementById("gmv-max-upload-status-toast");
    if (!toast)
        return;
    // Update status class
    toast.className = `gmv-max-upload-status-toast gmv-max-upload-status-${status}`;
    // Update icon and message
    let icon = "";
    let text = "";
    switch (status) {
        case "idle":
            toast.style.display = "none";
            return;
        case "uploading":
            icon = `<svg class="gmv-max-status-spinner" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
      </svg>`;
            text = message || "업로드 중...";
            break;
        case "success":
            icon = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>`;
            text = message || "업로드 완료!";
            break;
        case "error":
            icon = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>`;
            text = message || "업로드 실패";
            break;
    }
    toast.innerHTML = `
    <div class="gmv-max-status-content">
      ${icon}
      <span>${text}</span>
    </div>
  `;
    toast.style.display = "flex";
    // Auto-hide success/error messages after 5 seconds
    if (status === "success" || status === "error") {
        setTimeout(() => {
            toast.style.display = "none";
        }, 5000);
    }
}
/**
 * Inject status toast element above the Next Campaign button
 * Always visible but may show different states based on configuration
 */
async function injectUploadStatusToast() {
    // Check if toast already exists
    if (document.getElementById("gmv-max-upload-status-toast")) {
        return;
    }
    // Create toast element
    const toast = document.createElement("div");
    toast.id = "gmv-max-upload-status-toast";
    toast.className = "gmv-max-upload-status-toast gmv-max-upload-status-idle";
    // Add styles using a style tag for animations and complex selectors
    const styleTag = document.createElement("style");
    styleTag.textContent = `
    .gmv-max-upload-status-toast {
      position: fixed;
      bottom: 184px;
      right: 32px;
      z-index: 10000;
      background: white;
      border: 2px solid black;
      box-shadow: 0.2rem 0.2rem 0 0 black;
      padding: 12px 20px;
      font-size: 14px;
      font-weight: 600;
      display: none;
      align-items: center;
      gap: 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      width: 150px;
    }

    .gmv-max-status-content {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .gmv-max-upload-status-uploading {
      background: #eff6ff;
      border-color: #3b82f6;
      color: #1e40af;
    }

    .gmv-max-upload-status-success {
      background: #f0fdf4;
      border-color: #22c55e;
      color: #15803d;
    }

    .gmv-max-upload-status-error {
      background: #fef2f2;
      border-color: #ef4444;
      color: #991b1b;
    }

    .gmv-max-status-spinner {
      animation: gmv-max-spin 1s linear infinite;
    }

    @keyframes gmv-max-spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
  `;
    // Inject styles and toast
    document.head.appendChild(styleTag);
    document.body.appendChild(toast);
    console.log("[GMV Max Navigator] Upload status toast injected");
}
/**
 * Inject a date display box showing the configured date range
 * Positioned above the progress toast
 */
async function injectDateDisplayBox() {
    if (document.getElementById("gmv-max-date-display")) {
        return;
    }
    const dateBox = document.createElement("div");
    dateBox.id = "gmv-max-date-display";
    dateBox.className = "gmv-max-date-display";
    dateBox.style.cssText = `
    position: fixed;
    bottom: 238px; /* above progress toast (130px) and upload toast (184px) */
    right: 32px;
    z-index: 10000;
    background: white;
    border: 2px solid black;
    box-shadow: 0.2rem 0.2rem 0 0 black;
    padding: 10px 14px;
    font-size: 13px;
    font-weight: 600;
    display: none;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    width: 150px;
    text-align: center;
  `;
    document.body.appendChild(dateBox);
    await updateDateDisplay();
    console.log("[GMV Max Navigator] Date display box injected");
}
/**
 * Update the date display box with current configured date range
 */
async function updateDateDisplay() {
    const dateBox = document.getElementById("gmv-max-date-display");
    if (!dateBox)
        return;
    try {
        const result = await chrome.storage.local.get(["gmv_max_date_range"]);
        const dateRange = result.gmv_max_date_range;
        if (dateRange) {
            const startDate = `${dateRange.startDay}.${String(dateRange.startMonth).padStart(2, '0')}`;
            const endDate = `${dateRange.endDay}.${String(dateRange.endMonth).padStart(2, '0')}`;
            dateBox.textContent = `${startDate} - ${endDate}`;
            dateBox.style.display = "flex";
        }
        else {
            dateBox.style.display = "none";
        }
    }
    catch (e) {
        dateBox.style.display = "none";
    }
}
/**
 * Inject a permanent progress toast showing uploaded/total campaigns
 * Positioned between the upload status toast and the control buttons
 */
async function injectProgressToast() {
    if (document.getElementById("gmv-max-progress-toast")) {
        return;
    }
    const toast = document.createElement("div");
    toast.id = "gmv-max-progress-toast";
    toast.className = "gmv-max-progress-toast";
    toast.style.cssText = `
    position: fixed;
    bottom: 130px; /* between upload toast (150px) and buttons (85px) */
    right: 32px;
    z-index: 10000;
    background: white;
    border: 2px solid black;
    box-shadow: 0.2rem 0.2rem 0 0 black;
    padding: 10px 14px;
    font-size: 14px;
    font-weight: 700;
    display: none;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    width: 150px;
    text-align: center;
    position: fixed;
  `;
    // Create refetch button (always visible next to campaign number)
    const refetchBtn = document.createElement("button");
    refetchBtn.id = "gmv-max-refetch-btn";
    refetchBtn.className = "gmv-max-refetch-btn";
    refetchBtn.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
    </svg>
  `;
    refetchBtn.style.cssText = `
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-left: 5px;
    padding: 4px;
    width: 24px;
    height: 24px;
    border: 2px solid black;
    background: #ffffff;
    cursor: pointer;
    box-shadow: 0.15rem 0.15rem 0 0 black;
  `;
    // Click handler to ask background to re-check Drive and update statuses
    refetchBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        // Prevent multiple simultaneous requests but allow re-clicking after completion
        if (refetchBtn.classList.contains("refetching")) {
            return;
        }
        refetchBtn.classList.add("refetching");
        const originalHTML = refetchBtn.innerHTML;
        // Show "로딩 중..." text
        const countSpan = document.getElementById("gmv-max-progress-count");
        const originalCountText = (countSpan === null || countSpan === void 0 ? void 0 : countSpan.textContent) || "";
        if (countSpan) {
            countSpan.textContent = "로딩 중...";
        }
        // Show spinner animation in button
        refetchBtn.innerHTML = `
      <svg class="refetch-spinner" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
      </svg>
    `;
        // Add spinner animation style
        const spinnerStyle = document.createElement("style");
        spinnerStyle.textContent = `
      .refetch-spinner {
        animation: refetch-spin 1s linear infinite;
      }
      @keyframes refetch-spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
    `;
        if (!document.getElementById("refetch-spinner-style")) {
            spinnerStyle.id = "refetch-spinner-style";
            document.head.appendChild(spinnerStyle);
        }
        try {
            await new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({ type: "REFETCH_UPLOAD_STATUSES" }, (response) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                        return;
                    }
                    if (response === null || response === void 0 ? void 0 : response.success) {
                        resolve();
                    }
                    else {
                        reject(new Error((response === null || response === void 0 ? void 0 : response.error) || "Refetch failed"));
                    }
                });
            });
        }
        catch (_) {
            // Keep silent in content UI, rely on progress updating when possible
        }
        finally {
            await updateProgressToast();
            refetchBtn.innerHTML = originalHTML;
            refetchBtn.classList.remove("refetching");
        }
    });
    // Compose toast content container so numbers and button align
    const wrapper = document.createElement("div");
    wrapper.style.display = "flex";
    wrapper.style.alignItems = "center";
    wrapper.style.justifyContent = "space-between";
    wrapper.style.gap = "8px";
    wrapper.style.width = "100%";
    const countSpan = document.createElement("span");
    countSpan.id = "gmv-max-progress-count";
    wrapper.appendChild(countSpan);
    wrapper.appendChild(refetchBtn);
    toast.appendChild(wrapper);
    document.body.appendChild(toast);
    await updateProgressToast();
    console.log("[GMV Max Navigator] Progress toast injected");
}
/**
 * Compute and render uploaded/total campaigns in the progress toast
 */
async function updateProgressToast() {
    const toast = document.getElementById("gmv-max-progress-toast");
    if (!toast)
        return;
    try {
        const result = await chrome.storage.local.get([
            "gmv_max_campaign_data",
            "gmv_max_upload_success_status",
        ]);
        const campaigns = result.gmv_max_campaign_data || [];
        const successStatuses = result.gmv_max_upload_success_status || {};
        const total = campaigns.length;
        const uploaded = total === 0 ? 0 : campaigns.filter((c) => { var _a; return ((_a = successStatuses[c.name]) === null || _a === void 0 ? void 0 : _a.status) === "success"; }).length;
        if (total > 0) {
            // Show progress numbers by default, will be hidden on hover
            const countSpan = document.getElementById("gmv-max-progress-count");
            if (countSpan) {
                countSpan.textContent = `${uploaded}/${total}`;
                countSpan.style.display = "inline";
            }
            else {
                toast.textContent = ` ${uploaded}/${total}`;
            }
            toast.style.display = "flex";
        }
        else {
            toast.style.display = "none";
        }
    }
    catch (e) {
        // On error, hide to avoid stale display
        toast.style.display = "none";
    }
}
/**
 * Check campaigns and pause workflow if none pending
 */
async function checkAndPauseIfNoPendingCampaigns() {
    try {
        const result = await chrome.storage.local.get([
            "gmv_max_campaign_data",
            "gmv_max_upload_success_status",
        ]);
        const campaigns = result.gmv_max_campaign_data || [];
        const successStatuses = result.gmv_max_upload_success_status || {};
        const total = campaigns.length;
        const uploaded = total === 0 ? 0 : campaigns.filter((c) => { var _a; return ((_a = successStatuses[c.name]) === null || _a === void 0 ? void 0 : _a.status) === "success"; }).length;
        const hasPending = total > 0 && uploaded < total;
        if (!hasPending) {
            // No campaigns or all completed -> pause
            isAutoNavigationPaused = true;
            chrome.storage.local.set({ [WORKFLOW_PAUSED_KEY]: true });
            updateControlButtons();
            updateUploadStatusToast("idle");
            console.log("[GMV Max Navigator] No pending campaigns. Workflow paused.");
        }
    }
    catch (e) {
        // Ignore errors, do not force resume
    }
}
/**
 * Update control buttons visibility and state
 */
async function updateControlButtons() {
    const stopButton = document.getElementById("gmv-max-stop-btn");
    const resumeButton = document.getElementById("gmv-max-resume-btn");
    if (stopButton && resumeButton) {
        // Check if campaigns are configured (only need campaign data now)
        const result = await chrome.storage.local.get([
            "gmv_max_campaign_data",
            "gmv_max_upload_success_status",
        ]);
        const campaigns = result.gmv_max_campaign_data || [];
        const successStatuses = result.gmv_max_upload_success_status || {};
        const isConfigured = campaigns.length > 0;
        // Check if progress is full (all campaigns uploaded)
        const total = campaigns.length;
        const uploaded = total === 0 ? 0 : campaigns.filter((c) => { var _a; return ((_a = successStatuses[c.name]) === null || _a === void 0 ? void 0 : _a.status) === "success"; }).length;
        const isProgressFull = total > 0 && uploaded === total;
        // Disable buttons if not configured OR if progress is full
        const shouldDisable = !isConfigured || isProgressFull;
        stopButton.disabled = shouldDisable;
        resumeButton.disabled = shouldDisable;
        // Update opacity to show disabled state
        if (shouldDisable) {
            stopButton.style.opacity = "0.5";
            stopButton.style.cursor = "not-allowed";
            resumeButton.style.opacity = "0.5";
            resumeButton.style.cursor = "not-allowed";
        }
        else {
            stopButton.style.opacity = "1";
            stopButton.style.cursor = "pointer";
            resumeButton.style.opacity = "1";
            resumeButton.style.cursor = "pointer";
        }
        // Update visibility based on paused state
        if (isAutoNavigationPaused) {
            stopButton.style.display = "none";
            resumeButton.style.display = "flex";
        }
        else {
            stopButton.style.display = "flex";
            resumeButton.style.display = "none";
        }
    }
}
/**
 * Update navigation buttons state based on current configuration
 */
async function updateNavigationButtons() {
    const prevButton = document.getElementById("gmv-max-prev-campaign-btn");
    const nextButton = document.getElementById("gmv-max-next-campaign-btn");
    if (prevButton && nextButton) {
        // Check if campaigns are configured (only need campaign data now)
        const result = await chrome.storage.local.get(["gmv_max_campaign_data"]);
        const campaigns = result.gmv_max_campaign_data || [];
        const isConfigured = campaigns.length > 0;
        // Disable buttons if not configured
        const shouldDisable = !isConfigured;
        // Update button states
        prevButton.disabled = shouldDisable;
        prevButton.style.opacity = shouldDisable ? "0.5" : "1";
        prevButton.style.cursor = shouldDisable ? "not-allowed" : "pointer";
        nextButton.disabled = shouldDisable;
        nextButton.style.opacity = shouldDisable ? "0.5" : "1";
        nextButton.style.cursor = shouldDisable ? "not-allowed" : "pointer";
        console.log("[GMV Max Navigator] Navigation buttons state updated:", { isConfigured });
    }
}
/**
 * Inject stop and resume control buttons
 * Always visible, but disabled when campaigns are not configured
 */
async function injectControlButtons() {
    // Check if buttons already exist
    if (document.getElementById("gmv-max-stop-btn") || document.getElementById("gmv-max-resume-btn")) {
        return;
    }
    // Create Stop button
    const stopButton = document.createElement("button");
    stopButton.id = "gmv-max-stop-btn";
    stopButton.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="6" y="6" width="12" height="12"></rect>
    </svg>
    <span>일시정지</span>
  `;
    stopButton.style.cssText = `
    position: fixed;
    bottom: 85px;
    right: 32px;
    width: 150px;
    height: 40px;
    z-index: 10000;
    background: red;
    color: white;
    border: 2px solid black;
    box-shadow: 0.2rem 0.2rem 0 0 black;
    padding: 12px 18px;
    font-size: 14px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: pointer;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;
    // Create Resume button
    const resumeButton = document.createElement("button");
    resumeButton.id = "gmv-max-resume-btn";
    resumeButton.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polygon points="5 3 19 12 5 21 5 3"></polygon>
    </svg>
    <span>재개</span>
  `;
    resumeButton.style.cssText = `
    position: fixed;
    bottom: 85px;
    right: 32px;
    width: 150px;
    height: 40px;
    z-index: 10000;
    background: #22c55e;
    border: 2px solid black;
    box-shadow: 0.2rem 0.2rem 0 0 black;
    padding: 12px 18px;
    font-size: 14px;
    font-weight: 600;
    display: none;
    align-items: center;
    gap: 6px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: pointer;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    color: white;
  `;
    // Add hover effects for Stop button
    stopButton.addEventListener("mouseenter", () => {
        stopButton.style.boxShadow = "none";
    });
    stopButton.addEventListener("mouseleave", () => {
        stopButton.style.boxShadow = "0.2rem 0.2rem 0 0 black";
    });
    // Add hover effects for Resume button
    resumeButton.addEventListener("mouseenter", () => {
        resumeButton.style.boxShadow = "none";
    });
    resumeButton.addEventListener("mouseleave", () => {
        resumeButton.style.boxShadow = "0.2rem 0.2rem 0 0 black";
    });
    // Stop button click handler
    stopButton.addEventListener("click", async () => {
        if (stopButton.disabled)
            return;
        isAutoNavigationPaused = true;
        // Persist workflow paused state to localStorage
        chrome.storage.local.set({ [WORKFLOW_PAUSED_KEY]: true });
        await updateControlButtons();
        console.log("[GMV Max Navigator] Auto-navigation paused");
        updateUploadStatusToast("idle");
    });
    // Resume button click handler
    resumeButton.addEventListener("click", async () => {
        if (resumeButton.disabled)
            return;
        console.log("[GMV Max Navigator] Auto-navigation resumed, navigating to first campaign");
        isAutoNavigationPaused = false;
        // Persist workflow resumed state to localStorage
        chrome.storage.local.set({ [WORKFLOW_PAUSED_KEY]: false });
        // Reset the click flag to allow clicking again
        hasClickedExportButton = false;
        // Navigate to the first uncompleted campaign
        await goToFirstCampaign();
        // Update control buttons to show stop button
        updateControlButtons();
        // Enable navigation buttons
        updateNavigationButtons();
    });
    // Inject buttons
    document.body.appendChild(stopButton);
    document.body.appendChild(resumeButton);
    console.log("[GMV Max Navigator] Control buttons injected");
    // Set initial button visibility based on paused state
    updateControlButtons();
}
/**
 * Inject floating navigation buttons (Prev/Next) into the page
 * Always visible, but disabled when campaigns are not configured
 */
async function injectNavigationButtons() {
    // Check if buttons already exist
    if (document.getElementById("gmv-max-prev-campaign-btn") || document.getElementById("gmv-max-next-campaign-btn")) {
        return;
    }
    // Check if campaigns are configured (only need campaign data now)
    const result = await chrome.storage.local.get(["gmv_max_campaign_data"]);
    const campaigns = result.gmv_max_campaign_data || [];
    const isConfigured = campaigns.length > 0;
    // Create container for buttons
    const container = document.createElement("div");
    container.id = "gmv-max-navigation-container";
    container.style.cssText = `
    position: fixed;
    bottom: 32px;
    right: 32px;
    z-index: 10000;
    display: flex;
    gap: 4px;
    width: 150px;
  `;
    // Create Prev button
    const prevButton = document.createElement("button");
    prevButton.id = "gmv-max-prev-campaign-btn";
    prevButton.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="15 18 9 12 15 6"></polyline>
    </svg>
  `;
    // Set initial disabled state
    prevButton.disabled = !isConfigured;
    // Add styles for prev button
    prevButton.style.cssText = `
    flex: 1;
    background: white;
    color: black;
    border: 2px solid black;
    box-shadow: 0.2rem 0.2rem 0 0 black;
    padding: 12px;
    font-size: 15px;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: ${isConfigured ? "pointer" : "not-allowed"};
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    opacity: ${isConfigured ? "1" : "0.5"};
  `;
    // Create Next button
    const nextButton = document.createElement("button");
    nextButton.id = "gmv-max-next-campaign-btn";
    nextButton.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="9 18 15 12 9 6"></polyline>
    </svg>
  `;
    // Set initial disabled state
    nextButton.disabled = !isConfigured;
    // Add styles for next button
    nextButton.style.cssText = `
    flex: 1;
    background: black;
    color: white;
    border: 2px solid black;
    box-shadow: 0.2rem 0.2rem 0 0 black;
    padding: 12px;
    font-size: 15px;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: ${isConfigured ? "pointer" : "not-allowed"};
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    opacity: ${isConfigured ? "1" : "0.5"};
  `;
    // Add hover effects for prev button
    prevButton.addEventListener("mouseenter", () => {
        if (!prevButton.disabled) {
            prevButton.style.boxShadow = "none";
        }
    });
    prevButton.addEventListener("mouseleave", () => {
        if (!prevButton.disabled) {
            prevButton.style.boxShadow = "0.2rem 0.2rem 0 0 black";
        }
    });
    // Add hover effects for next button
    nextButton.addEventListener("mouseenter", () => {
        if (!nextButton.disabled) {
            nextButton.style.boxShadow = "none";
        }
    });
    nextButton.addEventListener("mouseleave", () => {
        if (!nextButton.disabled) {
            nextButton.style.boxShadow = "0.2rem 0.2rem 0 0 black";
        }
    });
    // Add click handler for prev button
    prevButton.addEventListener("click", async () => {
        if (prevButton.disabled)
            return;
        const originalDisabled = prevButton.disabled;
        prevButton.disabled = true;
        prevButton.style.opacity = "0.6";
        prevButton.style.cursor = "not-allowed";
        try {
            await goToPrevCampaign();
        }
        finally {
            prevButton.disabled = originalDisabled;
            prevButton.style.opacity = isConfigured ? "1" : "0.5";
            prevButton.style.cursor = isConfigured ? "pointer" : "not-allowed";
        }
    });
    // Add click handler for next button
    nextButton.addEventListener("click", async () => {
        if (nextButton.disabled)
            return;
        const originalDisabled = nextButton.disabled;
        nextButton.disabled = true;
        nextButton.style.opacity = "0.6";
        nextButton.style.cursor = "not-allowed";
        try {
            await goToNextCampaign();
        }
        finally {
            nextButton.disabled = originalDisabled;
            nextButton.style.opacity = isConfigured ? "1" : "0.5";
            nextButton.style.cursor = isConfigured ? "pointer" : "not-allowed";
        }
    });
    // Append buttons to container
    container.appendChild(prevButton);
    container.appendChild(nextButton);
    // Inject container into page
    document.body.appendChild(container);
    console.log("[GMV Max Navigator] Navigation buttons injected");
}
/**
 * Listen for upload status messages from background script
 */
chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "UPLOAD_STATUS") {
        console.log("[GMV Max Navigator] Received upload status:", message);
        // Get campaign info from current URL to check if this status update is for the current campaign
        const campaignId = getCampaignIdFromUrl();
        if (!campaignId)
            return;
        getCampaignName(campaignId).then((campaignName) => {
            // Only show status if it's for the current campaign
            if (campaignName === message.campaignName) {
                switch (message.status) {
                    case "started":
                        updateUploadStatusToast("uploading", "업로드 중...");
                        updateProgressToast();
                        break;
                    case "success":
                        updateUploadStatusToast("success", "업로드 완료");
                        // Persist success to chrome.storage so progress stays accurate even if popup is closed
                        chrome.storage.local.get(["gmv_max_upload_success_status"], (result) => {
                            const successStatuses = result.gmv_max_upload_success_status || {};
                            successStatuses[message.campaignName] = { status: "success" };
                            chrome.storage.local.set({ gmv_max_upload_success_status: successStatuses }, () => {
                                updateProgressToast();
                            });
                        });
                        // Auto-click "Next Campaign" button after successful upload (only if not paused)
                        if (!isAutoNavigationPaused) {
                            console.log(`[GMV Max Navigator] Upload successful, auto-clicking next campaign button in ${AUTO_NAVIGATION_DELAY / 1000} seconds...`);
                            setTimeout(() => {
                                // Check again if still not paused (user might have clicked stop during delay)
                                if (!isAutoNavigationPaused) {
                                    const nextButton = document.getElementById("gmv-max-next-campaign-btn");
                                    if (nextButton) {
                                        console.log("[GMV Max Navigator] Auto-clicking next campaign button");
                                        nextButton.click();
                                    }
                                    else {
                                        console.warn("[GMV Max Navigator] Next campaign button not found");
                                    }
                                }
                                else {
                                    console.log("[GMV Max Navigator] Auto-navigation is paused, skipping auto-click");
                                }
                            }, AUTO_NAVIGATION_DELAY);
                        }
                        else {
                            console.log("[GMV Max Navigator] Auto-navigation is paused, skipping auto-click");
                        }
                        break;
                    case "error":
                        updateUploadStatusToast("error", `업로드 실패: ${message.error || "알 수 없는 오류"}`);
                        updateProgressToast();
                        break;
                }
            }
        });
    }
});
/**
 * Listen for storage changes and update button states accordingly
 */
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local") {
        // Check if campaign data changed
        if (changes["gmv_max_campaign_data"]) {
            console.log("[GMV Max Navigator] Configuration changed, updating button states");
            // Update all buttons that depend on configuration
            updateNavigationButtons();
            updateControlButtons();
        }
        // Update progress when relevant storage keys change
        if (changes["gmv_max_campaign_data"] || changes["gmv_max_upload_success_status"]) {
            updateProgressToast();
            // Auto-pause when everything is completed or no campaigns exist
            checkAndPauseIfNoPendingCampaigns();
        }
        // Update date display when date range changes
        if (changes["gmv_max_date_range"]) {
            updateDateDisplay();
        }
    }
});
/**
 * Initialize auto-click functionality
 * Checks if feature is enabled in storage before attempting
 */
async function initialize() {
    try {
        // Check if we're on the correct URL
        const urlPattern = /ads\.tiktok\.com\/i18n\/gmv-max\/dashboard/;
        if (!urlPattern.test(window.location.href)) {
            console.log("[GMV Max Navigator] Not on GMV Max dashboard page");
            return;
        }
        console.log("[GMV Max Navigator] Initializing on GMV Max dashboard");
        // Restore paused/resumed state from storage (default to paused)
        try {
            const storedState = await chrome.storage.local.get([WORKFLOW_PAUSED_KEY]);
            // If explicitly set to false, it means resumed; otherwise treat as paused by default
            isAutoNavigationPaused = storedState[WORKFLOW_PAUSED_KEY] !== false;
            console.log("[GMV Max Navigator] Restored paused state:", isAutoNavigationPaused);
        }
        catch (e) {
            console.warn("[GMV Max Navigator] Failed to restore paused state, defaulting to paused");
            isAutoNavigationPaused = true;
        }
        // Inject UI elements (always visible, disabled if not configured)
        await injectNavigationButtons();
        await injectUploadStatusToast();
        await injectDateDisplayBox();
        await injectProgressToast();
        await injectControlButtons();
        // Ensure paused when there are no campaigns to upload
        await checkAndPauseIfNoPendingCampaigns();
        // Check if auto-click is enabled
        const result = await chrome.storage.local.get([STORAGE_KEY]);
        const isEnabled = result[STORAGE_KEY] !== false; // Default to true
        if (!isEnabled) {
            console.log("[GMV Max Navigator] Auto-click is disabled");
            return;
        }
        console.log("[GMV Max Navigator] Auto-click is enabled");
        // Only start auto-click if not paused
        if (!isAutoNavigationPaused) {
            console.log("[GMV Max Navigator] Starting auto-click workflow");
            // Start attempting to click the button
            attemptAutoClick();
            // Also observe for dynamic content changes
            const observer = new MutationObserver((mutations) => {
                // Check if any mutations added nodes
                const hasNewNodes = mutations.some(mutation => mutation.addedNodes.length > 0);
                if (hasNewNodes) {
                    // Debounce: only check once after changes settle
                    const clicked = findAndClickExportButton();
                    if (clicked) {
                        observer.disconnect(); // Stop observing once we've clicked
                    }
                }
            });
            // Observe the entire document for changes
            observer.observe(document.body, {
                childList: true,
                subtree: true,
            });
            // Disconnect observer after a reasonable time to avoid memory leaks
            setTimeout(() => observer.disconnect(), 30000); // 30 seconds
        }
        else {
            console.log("[GMV Max Navigator] Auto-click workflow is paused, waiting for user to resume");
        }
    }
    catch (error) {
        console.error("[GMV Max Navigator] Error in auto-click initialization:", error);
    }
}
// Run initialization when DOM is ready
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
}
else {
    initialize();
}

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ087QUFDQTtBQUNQLE1BQU0saURBQWlEO0FBQ3ZELE1BQU07QUFDTjs7Ozs7Ozs7Ozs7Ozs7O0FDOUJPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNWcUQ7QUFDckQ7QUFDQTtBQUNBO0FBQ087QUFDUCxtQkFBbUIsNkRBQWE7QUFDaEM7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDUitEO0FBQy9EO0FBQ0E7QUFDQTtBQUNPO0FBQ1AsbUJBQW1CLDZEQUFhO0FBQ2hDO0FBQ0E7QUFDQSxVQUFVLHdEQUFRO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxjQUFjLFFBQVEsR0FBRyxrQkFBa0I7QUFDM0M7Ozs7Ozs7VUNwQkE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7Ozs7V0N0QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQSxFOzs7OztXQ1BBLHdGOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RCxFOzs7Ozs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDbUQ7QUFDUTtBQUNKO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3Qix1Q0FBdUM7QUFDdkMsb0NBQW9DO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNERBQTRELDBCQUEwQjtBQUN0RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxRQUFRLEdBQUcsb0JBQW9CO0FBQzlFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksNERBQVk7QUFDeEIsWUFBWSw0REFBWTtBQUN4QixZQUFZLDREQUFZO0FBQ3hCLFlBQVksNERBQVk7QUFDeEIsWUFBWSw0REFBWTtBQUN4QixZQUFZLDREQUFZO0FBQ3hCO0FBQ0EsaUNBQWlDLDREQUFZO0FBQzdDLDZDQUE2Qyw0REFBWTtBQUN6RCwyQ0FBMkMsNERBQVk7QUFDdkQsdUNBQXVDLDREQUFZO0FBQ25ELHFDQUFxQyw0REFBWTtBQUNqRCxpQ0FBaUMsNERBQVk7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLFFBQVE7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxtQkFBbUI7QUFDbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBEQUEwRCxjQUFjO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBLCtCQUErQix3RUFBcUI7QUFDcEQsNkJBQTZCLHdFQUFxQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsb0VBQWdCO0FBQ3ZDO0FBQ0EseUNBQXlDLENBQUMsNERBQVksdUNBQXVDO0FBQzdGLDRFQUE0RSxjQUFjO0FBQzFGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSw0REFBWTtBQUN4QixZQUFZLDREQUFZO0FBQ3hCLFlBQVksNERBQVk7QUFDeEIsWUFBWSw0REFBWTtBQUN4QixZQUFZLDREQUFZO0FBQ3hCO0FBQ0EsaUNBQWlDLDREQUFZO0FBQzdDLDJDQUEyQyw0REFBWTtBQUN2RCx1Q0FBdUMsNERBQVk7QUFDbkQscUNBQXFDLDREQUFZO0FBQ2pELGlDQUFpQyw0REFBWTtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixzQkFBc0I7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwREFBMEQsY0FBYztBQUN4RTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0Isd0VBQXFCO0FBQ3BELDZCQUE2Qix3RUFBcUI7QUFDbEQ7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLG9FQUFnQjtBQUN2QztBQUNBLHlDQUF5QyxDQUFDLDREQUFZLHdDQUF3QztBQUM5Rix5RUFBeUUsY0FBYztBQUN2RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksNERBQVk7QUFDeEIsWUFBWSw0REFBWTtBQUN4QixZQUFZLDREQUFZO0FBQ3hCLFlBQVksNERBQVk7QUFDeEIsWUFBWSw0REFBWTtBQUN4QixZQUFZLDREQUFZO0FBQ3hCO0FBQ0EsaUNBQWlDLDREQUFZO0FBQzdDLDZDQUE2Qyw0REFBWTtBQUN6RCwyQ0FBMkMsNERBQVk7QUFDdkQsdUNBQXVDLDREQUFZO0FBQ25ELHFDQUFxQyw0REFBWTtBQUNqRCxpQ0FBaUMsNERBQVk7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLHNCQUFzQjtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLG1CQUFtQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMERBQTBELGNBQWM7QUFDeEU7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLHdFQUFxQjtBQUNwRCw2QkFBNkIsd0VBQXFCO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixvRUFBZ0I7QUFDdkM7QUFDQSx5Q0FBeUMsQ0FBQyw0REFBWSx1Q0FBdUM7QUFDN0Ysd0VBQXdFLGNBQWM7QUFDdEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkVBQTJFLE9BQU87QUFDbEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1IsY0FBYyxLQUFLO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsbUJBQW1CLEdBQUcsOENBQThDO0FBQ3JHLCtCQUErQixpQkFBaUIsR0FBRyw0Q0FBNEM7QUFDL0YscUNBQXFDLFdBQVcsSUFBSSxRQUFRO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlO0FBQ2YsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2Q0FBNkMsaUNBQWlDO0FBQzlFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxRUFBcUUsUUFBUSx1R0FBdUc7QUFDcEw7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQ0FBMkMsU0FBUyxHQUFHLE1BQU07QUFDN0Q7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLFNBQVMsR0FBRyxNQUFNO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFFQUFxRSxRQUFRLHVHQUF1RztBQUNwTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1Qyw2QkFBNkI7QUFDcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFFQUFxRSxRQUFRLHVHQUF1RztBQUNwTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtFQUErRSxjQUFjO0FBQzdGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsNkJBQTZCO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyw4QkFBOEI7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNFQUFzRTtBQUN0RSx1REFBdUQsZ0RBQWdEO0FBQ3ZHO0FBQ0EsNkJBQTZCO0FBQzdCLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0Esd0hBQXdILDhCQUE4QjtBQUN0SjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0VBQW9FLDZCQUE2QjtBQUNqRztBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkRBQTZEO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5REFBeUQ7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQStDO0FBQy9DO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSw0REFBNEQ7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9nbXYtbWF4LWF1dG9tYXRpb24vLi9leHRlbnNpb24vY29uc3RhbnRzL3JlZ2lvbnMudHMiLCJ3ZWJwYWNrOi8vZ212LW1heC1hdXRvbWF0aW9uLy4vZXh0ZW5zaW9uL2NvbnN0YW50cy9zdG9yYWdlLnRzIiwid2VicGFjazovL2dtdi1tYXgtYXV0b21hdGlvbi8uL2V4dGVuc2lvbi91dGlscy9kYXRlLXV0aWxzLnRzIiwid2VicGFjazovL2dtdi1tYXgtYXV0b21hdGlvbi8uL2V4dGVuc2lvbi91dGlscy91cmwtYnVpbGRlci50cyIsIndlYnBhY2s6Ly9nbXYtbWF4LWF1dG9tYXRpb24vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vZ212LW1heC1hdXRvbWF0aW9uL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly9nbXYtbWF4LWF1dG9tYXRpb24vd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9nbXYtbWF4LWF1dG9tYXRpb24vd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9nbXYtbWF4LWF1dG9tYXRpb24vLi9leHRlbnNpb24vY29udGVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUkVHSU9OX0NPTkZJRyA9IHtcbiAgICBVUzoge1xuICAgICAgICBhYWR2aWQ6IFwiNjg2MDA1Mzk1MTA3MzQ4NDgwNlwiLFxuICAgICAgICBvZWNfc2VsbGVyX2lkOiBcIjc0OTUyNzU2MTc4ODc5NDcyMDJcIixcbiAgICAgICAgYmNfaWQ6IFwiNzI3ODU1NjY0MzA2MTc5Mjc2OVwiLFxuICAgICAgICB1dGNPZmZzZXQ6IDksIC8vIFVUQyswOTowMFxuICAgIH0sXG4gICAgSUQ6IHtcbiAgICAgICAgYWFkdmlkOiBcIjcyMDgxMDU3NjcyOTM5OTI5NjJcIixcbiAgICAgICAgb2VjX3NlbGxlcl9pZDogXCI3NDk0OTI4NzQ4MzAyMDc2NzA4XCIsXG4gICAgICAgIGJjX2lkOiBcIjcyMDgxMDY4NjIxMjg5MzkwMDlcIixcbiAgICAgICAgdXRjT2Zmc2V0OiA3LCAvLyBVVEMrMDc6MDBcbiAgICB9LFxuICAgIFBIOiB7XG4gICAgICAgIGFhZHZpZDogXCI3MjY1MTk4Njc2MTQ5MDc1OTY5XCIsXG4gICAgICAgIG9lY19zZWxsZXJfaWQ6IFwiNzQ5NTE2ODE4NDkyMTE5Njc4NlwiLFxuICAgICAgICBiY19pZDogXCI3MjY1MTk4NTcyMDU0ODg4NDQ5XCIsXG4gICAgICAgIHV0Y09mZnNldDogOCwgLy8gVVRDKzA4OjAwXG4gICAgfSxcbiAgICBNWToge1xuICAgICAgICBhYWR2aWQ6IFwiNzUyNTI1NzI5NTU1NTc3MjQyM1wiLFxuICAgICAgICBvZWNfc2VsbGVyX2lkOiBcIjc0OTYyNjE2NDQxNDYxNTAxOThcIixcbiAgICAgICAgYmNfaWQ6IFwiNzUyNTI1NjE3ODM5ODY3NDk1MlwiLFxuICAgICAgICB1dGNPZmZzZXQ6IDgsIC8vIFVUQyswODowMFxuICAgIH0sXG59O1xuZXhwb3J0IGNvbnN0IEJBU0VfVVJMID0gXCJodHRwczovL2Fkcy50aWt0b2suY29tL2kxOG4vZ212LW1heC9kYXNoYm9hcmQvcHJvZHVjdFwiO1xuZXhwb3J0IGNvbnN0IExJVkVfQ0FNUEFJR05TID0gW1xuICAgIHsgbmFtZTogXCJTS0lOMTAwNE1ZKDFzdClcIiwgaWQ6IFwiMTg0MjAyMTczOTU5MDgxN1wiIH0sXG4gICAgeyBuYW1lOiBcInNraW4xMDA0bXlfb2ZmaWNpYWxfMjUwOTA5XCIsIGlkOiBcIjE4NDI3NzE3NTM0NDU0MTBcIiB9XG5dO1xuIiwiZXhwb3J0IGNvbnN0IFNUT1JBR0VfS0VZUyA9IHtcbiAgICBDQU1QQUlHTl9EQVRBOiBcImdtdl9tYXhfY2FtcGFpZ25fZGF0YVwiLFxuICAgIENVUlJFTlRfSU5ERVg6IFwiZ212X21heF9jdXJyZW50X2luZGV4XCIsXG4gICAgQ09NUExFVEVEX0NBTVBBSUdOUzogXCJnbXZfbWF4X2NvbXBsZXRlZF9jYW1wYWlnbnNcIixcbiAgICBBVVRPX0NMSUNLX0VOQUJMRUQ6IFwiZ212X21heF9hdXRvX2NsaWNrX2VuYWJsZWRcIixcbiAgICBMQVNUX1VQTE9BRF9TVEFUVVM6IFwibGFzdFVwbG9hZFN0YXR1c1wiLFxuICAgIFVQTE9BRF9TVUNDRVNTX1NUQVRVUzogXCJnbXZfbWF4X3VwbG9hZF9zdWNjZXNzX3N0YXR1c1wiLFxuICAgIENBTVBBSUdOX1JFR0lPTlM6IFwiZ212X21heF9jYW1wYWlnbl9yZWdpb25zXCIsXG4gICAgQ0FNUEFJR05fVFlQRVM6IFwiZ212X21heF9jYW1wYWlnbl90eXBlc1wiLFxuICAgIERBVEVfUkFOR0U6IFwiZ212X21heF9kYXRlX3JhbmdlXCIsXG59O1xuIiwiaW1wb3J0IHsgUkVHSU9OX0NPTkZJRyB9IGZyb20gXCIuLi9jb25zdGFudHMvcmVnaW9uc1wiO1xuLyoqXG4gKiBDb252ZXJ0IHJlZ2lvbi1zcGVjaWZpYyBkYXRlIHRvIHRpbWVzdGFtcFxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVnaW9uRGF0ZVRvVGltZXN0YW1wKHJlZ2lvbiwgeWVhciwgbW9udGgsIGRheSwgaG91ciA9IDAsIG1pbnV0ZSA9IDAsIHNlY29uZCA9IDApIHtcbiAgICBjb25zdCBvZmZzZXQgPSBSRUdJT05fQ09ORklHW3JlZ2lvbl0udXRjT2Zmc2V0O1xuICAgIGNvbnN0IHV0Y0RhdGUgPSBuZXcgRGF0ZShEYXRlLlVUQyh5ZWFyLCBtb250aCAtIDEsIGRheSwgaG91ciAtIG9mZnNldCwgbWludXRlLCBzZWNvbmQpKTtcbiAgICByZXR1cm4gdXRjRGF0ZS5nZXRUaW1lKCk7XG59XG4iLCJpbXBvcnQgeyBSRUdJT05fQ09ORklHLCBCQVNFX1VSTCB9IGZyb20gXCIuLi9jb25zdGFudHMvcmVnaW9uc1wiO1xuLyoqXG4gKiBCdWlsZCBjYW1wYWlnbiBVUkwgd2l0aCByZWdpb24tc3BlY2lmaWMgcGFyYW1ldGVyc1xuICovXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRDYW1wYWlnblVybChyZWdpb24sIGNhbXBhaWduSWQsIHN0YXJ0VGltZXN0YW1wLCBlbmRUaW1lc3RhbXAsIGNhbXBhaWduVHlwZSA9IFwiUFJPRFVDVFwiKSB7XG4gICAgY29uc3QgY29uZmlnID0gUkVHSU9OX0NPTkZJR1tyZWdpb25dO1xuICAgIGNvbnN0IGJhc2VVcmwgPSBjYW1wYWlnblR5cGUgPT09IFwiTElWRVwiXG4gICAgICAgID8gXCJodHRwczovL2Fkcy50aWt0b2suY29tL2kxOG4vZ212LW1heC9kYXNoYm9hcmQvbGl2ZVwiXG4gICAgICAgIDogQkFTRV9VUkw7XG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh7XG4gICAgICAgIGFhZHZpZDogY29uZmlnLmFhZHZpZCxcbiAgICAgICAgb2VjX3NlbGxlcl9pZDogY29uZmlnLm9lY19zZWxsZXJfaWQsXG4gICAgICAgIGJjX2lkOiBjb25maWcuYmNfaWQsXG4gICAgICAgIHR5cGU6IGNhbXBhaWduVHlwZS50b0xvd2VyQ2FzZSgpLFxuICAgICAgICBsaXN0X3N0YXR1czogXCJkZWxpdmVyeV9va1wiLFxuICAgICAgICBjYW1wYWlnbl9pZDogY2FtcGFpZ25JZCxcbiAgICAgICAgY2FtcGFpZ25fc3RhcnRfZGF0ZTogc3RhcnRUaW1lc3RhbXAudG9TdHJpbmcoKSxcbiAgICAgICAgY2FtcGFpZ25fZW5kX2RhdGU6IGVuZFRpbWVzdGFtcC50b1N0cmluZygpLFxuICAgIH0pO1xuICAgIHJldHVybiBgJHtiYXNlVXJsfT8ke3BhcmFtcy50b1N0cmluZygpfWA7XG59XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIi8qKlxuICogQ29udGVudCBzY3JpcHQgZm9yIGF1dG8tY2xpY2tpbmcgZXhwb3J0IGJ1dHRvbiBvbiBUaWtUb2sgQWRzIEdNViBNYXggZGFzaGJvYXJkXG4gKiBSdW5zIG9uIGNhbXBhaWduIHBhZ2VzIGFuZCBhdXRvbWF0aWNhbGx5IGNsaWNrcyB0aGUgZXhwb3J0IGJ1dHRvbiB3aGVuIGF2YWlsYWJsZVxuICogQWxzbyBkZXRlY3RzIGRvd25sb2FkZWQgZmlsZXMgYW5kIHRyaWdnZXJzIHVwbG9hZCB0byBHb29nbGUgRHJpdmVcbiAqL1xuaW1wb3J0IHsgU1RPUkFHRV9LRVlTIH0gZnJvbSBcIi4vY29uc3RhbnRzL3N0b3JhZ2VcIjtcbmltcG9ydCB7IHJlZ2lvbkRhdGVUb1RpbWVzdGFtcCB9IGZyb20gXCIuL3V0aWxzL2RhdGUtdXRpbHNcIjtcbmltcG9ydCB7IGJ1aWxkQ2FtcGFpZ25VcmwgfSBmcm9tIFwiLi91dGlscy91cmwtYnVpbGRlclwiO1xuY29uc3QgU1RPUkFHRV9LRVkgPSBcImdtdl9tYXhfYXV0b19jbGlja19lbmFibGVkXCI7XG5jb25zdCBXT1JLRkxPV19QQVVTRURfS0VZID0gXCJnbXZfbWF4X3dvcmtmbG93X3BhdXNlZFwiO1xuY29uc3QgTUFYX1JFVFJZX0FUVEVNUFRTID0gMTA7XG5jb25zdCBSRVRSWV9JTlRFUlZBTCA9IDEwMDA7IC8vIDEgc2Vjb25kXG5jb25zdCBET1dOTE9BRF9ERVRFQ1RJT05fREVMQVkgPSAzMDAwOyAvLyBXYWl0IDMgc2Vjb25kcyBhZnRlciBjbGlja2luZyBiZWZvcmUgY2hlY2tpbmcgZG93bmxvYWRzXG5jb25zdCBBVVRPX05BVklHQVRJT05fREVMQVkgPSAyMDAwOyAvLyBXYWl0IDIgc2Vjb25kcyBhZnRlciB1cGxvYWQgc3VjY2VzcyBiZWZvcmUgYXV0by1uYXZpZ2F0aW5nIHRvIG5leHQgY2FtcGFpZ25cbi8vIERlZHVwbGljYXRpb246IFRyYWNrIGlmIHdlJ3ZlIGFscmVhZHkgY2xpY2tlZCB0byBwcmV2ZW50IGR1cGxpY2F0ZSB1cGxvYWRzXG5sZXQgaGFzQ2xpY2tlZEV4cG9ydEJ1dHRvbiA9IGZhbHNlO1xubGV0IHVwbG9hZEluUHJvZ3Jlc3MgPSBmYWxzZTtcbi8vIEF1dG8tbmF2aWdhdGlvbiBjb250cm9sIC0gbG9hZCBmcm9tIGxvY2FsU3RvcmFnZSwgZGVmYXVsdCBzdGF0ZSBpcyBwYXVzZWRcbmxldCBpc0F1dG9OYXZpZ2F0aW9uUGF1c2VkID0gdHJ1ZTtcbi8qKlxuICogQXR0ZW1wdCB0byBmaW5kIGFuZCBjbGljayB0aGUgZXhwb3J0IGJ1dHRvblxuICogVXNlcyBtdWx0aXBsZSBzZWxlY3RvciBzdHJhdGVnaWVzIGZvciByb2J1c3RuZXNzXG4gKiBJbmNsdWRlcyBkZWR1cGxpY2F0aW9uIHRvIHByZXZlbnQgbXVsdGlwbGUgY2xpY2tzXG4gKi9cbmZ1bmN0aW9uIGZpbmRBbmRDbGlja0V4cG9ydEJ1dHRvbigpIHtcbiAgICAvLyBQcmV2ZW50IGR1cGxpY2F0ZSBjbGlja3NcbiAgICBpZiAoaGFzQ2xpY2tlZEV4cG9ydEJ1dHRvbikge1xuICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gRXhwb3J0IGJ1dHRvbiBhbHJlYWR5IGNsaWNrZWQsIHNraXBwaW5nXCIpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgLy8gU3RyYXRlZ3kgMTogVXNlIGRhdGEtdGVzdGlkIGF0dHJpYnV0ZSAobW9zdCByZWxpYWJsZSlcbiAgICBjb25zdCBidXR0b25CeVRlc3RJZCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2J1dHRvbltkYXRhLXRlc3RpZD1cImV4cG9ydC1idXR0b24taW5kZXgtd041UVJyXCJdJyk7XG4gICAgaWYgKGJ1dHRvbkJ5VGVzdElkKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBGb3VuZCBleHBvcnQgYnV0dG9uIGJ5IHRlc3QgSURcIik7XG4gICAgICAgIGhhc0NsaWNrZWRFeHBvcnRCdXR0b24gPSB0cnVlO1xuICAgICAgICBidXR0b25CeVRlc3RJZC5jbGljaygpO1xuICAgICAgICAvLyBUcmlnZ2VyIGRvd25sb2FkIGRldGVjdGlvbiBhZnRlciBjbGlja2luZ1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGRldGVjdEFuZFVwbG9hZERvd25sb2FkZWRGaWxlKCksIERPV05MT0FEX0RFVEVDVElPTl9ERUxBWSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICAvLyBTdHJhdGVneSAyOiBVc2UgZGF0YS10ZWEtY2xpY2tfZm9yIGF0dHJpYnV0ZVxuICAgIGNvbnN0IGJ1dHRvbkJ5VGVhQ2xpY2sgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdidXR0b25bZGF0YS10ZWEtY2xpY2tfZm9yPVwiZXhwb3J0X2J1dHRvbl92aWV3X2RhdGFfcHJvZHVjdFwiXScpO1xuICAgIGlmIChidXR0b25CeVRlYUNsaWNrKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBGb3VuZCBleHBvcnQgYnV0dG9uIGJ5IHRlYS1jbGljayBhdHRyaWJ1dGVcIik7XG4gICAgICAgIGhhc0NsaWNrZWRFeHBvcnRCdXR0b24gPSB0cnVlO1xuICAgICAgICBidXR0b25CeVRlYUNsaWNrLmNsaWNrKCk7XG4gICAgICAgIC8vIFRyaWdnZXIgZG93bmxvYWQgZGV0ZWN0aW9uIGFmdGVyIGNsaWNraW5nXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gZGV0ZWN0QW5kVXBsb2FkRG93bmxvYWRlZEZpbGUoKSwgRE9XTkxPQURfREVURUNUSU9OX0RFTEFZKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIC8vIFN0cmF0ZWd5IDM6IFVzZSBkYXRhLXRpZCBhdHRyaWJ1dGVcbiAgICBjb25zdCBidXR0b25CeVRpZCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2J1dHRvbltkYXRhLXRpZD1cIm00Yl9idXR0b25cIl1bZGF0YS11aWQqPVwiZXhwb3J0YnV0dG9uXCJdJyk7XG4gICAgaWYgKGJ1dHRvbkJ5VGlkKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBGb3VuZCBleHBvcnQgYnV0dG9uIGJ5IHRpZCBhdHRyaWJ1dGVcIik7XG4gICAgICAgIGhhc0NsaWNrZWRFeHBvcnRCdXR0b24gPSB0cnVlO1xuICAgICAgICBidXR0b25CeVRpZC5jbGljaygpO1xuICAgICAgICAvLyBUcmlnZ2VyIGRvd25sb2FkIGRldGVjdGlvbiBhZnRlciBjbGlja2luZ1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGRldGVjdEFuZFVwbG9hZERvd25sb2FkZWRGaWxlKCksIERPV05MT0FEX0RFVEVDVElPTl9ERUxBWSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICAvLyBTdHJhdGVneSA0OiBMb29rIGZvciBidXR0b24gd2l0aCBsYXVuY2ggaWNvbiBTVkdcbiAgICBjb25zdCBidXR0b25zID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnYnV0dG9uLnRoZW1lLW00Yi1idXR0b24nKTtcbiAgICBmb3IgKGNvbnN0IGJ1dHRvbiBvZiBidXR0b25zKSB7XG4gICAgICAgIGNvbnN0IHN2ZyA9IGJ1dHRvbi5xdWVyeVNlbGVjdG9yKCdzdmcudGhlbWUtYXJjby1pY29uLWxhdW5jaCcpO1xuICAgICAgICBpZiAoc3ZnKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gRm91bmQgZXhwb3J0IGJ1dHRvbiBieSBTVkcgaWNvblwiKTtcbiAgICAgICAgICAgIGhhc0NsaWNrZWRFeHBvcnRCdXR0b24gPSB0cnVlO1xuICAgICAgICAgICAgYnV0dG9uLmNsaWNrKCk7XG4gICAgICAgICAgICAvLyBUcmlnZ2VyIGRvd25sb2FkIGRldGVjdGlvbiBhZnRlciBjbGlja2luZ1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBkZXRlY3RBbmRVcGxvYWREb3dubG9hZGVkRmlsZSgpLCBET1dOTE9BRF9ERVRFQ1RJT05fREVMQVkpO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuLyoqXG4gKiBFeHRyYWN0IGNhbXBhaWduIElEIGZyb20gY3VycmVudCBVUkxcbiAqL1xuZnVuY3Rpb24gZ2V0Q2FtcGFpZ25JZEZyb21VcmwoKSB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTCh3aW5kb3cubG9jYXRpb24uaHJlZik7XG4gICAgcmV0dXJuIHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwiY2FtcGFpZ25faWRcIik7XG59XG4vKipcbiAqIEdldCBjYW1wYWlnbiBuYW1lIGZyb20gbG9jYWxTdG9yYWdlIHVzaW5nIGNhbXBhaWduIElEXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGdldENhbXBhaWduTmFtZShjYW1wYWlnbklkKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbXCJnbXZfbWF4X2NhbXBhaWduX2RhdGFcIl0sIChyZXN1bHQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNhbXBhaWducyA9IHJlc3VsdC5nbXZfbWF4X2NhbXBhaWduX2RhdGEgfHwgW107XG4gICAgICAgICAgICBjb25zdCBjYW1wYWlnbiA9IGNhbXBhaWducy5maW5kKChjKSA9PiBjLmlkID09PSBjYW1wYWlnbklkKTtcbiAgICAgICAgICAgIHJlc29sdmUoY2FtcGFpZ24gPyBjYW1wYWlnbi5uYW1lIDogbnVsbCk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuLyoqXG4gKiBEZXRlY3QgYW5kIHVwbG9hZCB0aGUgbW9zdCByZWNlbnRseSBkb3dubG9hZGVkIGZpbGVcbiAqIFNlbmRzIHJlcXVlc3QgdG8gYmFja2dyb3VuZCBzY3JpcHQgd2hpY2ggaGFzIGFjY2VzcyB0byBkb3dubG9hZHMgQVBJXG4gKiBJbmNsdWRlcyBkZWR1cGxpY2F0aW9uIHRvIHByZXZlbnQgbXVsdGlwbGUgdXBsb2Fkc1xuICovXG5hc3luYyBmdW5jdGlvbiBkZXRlY3RBbmRVcGxvYWREb3dubG9hZGVkRmlsZSgpIHtcbiAgICB0cnkge1xuICAgICAgICAvLyBQcmV2ZW50IGR1cGxpY2F0ZSB1cGxvYWRzXG4gICAgICAgIGlmICh1cGxvYWRJblByb2dyZXNzKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gVXBsb2FkIGFscmVhZHkgaW4gcHJvZ3Jlc3MsIHNraXBwaW5nXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHVwbG9hZEluUHJvZ3Jlc3MgPSB0cnVlO1xuICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gRGV0ZWN0aW5nIGRvd25sb2FkZWQgZmlsZS4uLlwiKTtcbiAgICAgICAgLy8gR2V0IGNhbXBhaWduIGluZm8gZnJvbSBVUkxcbiAgICAgICAgY29uc3QgY2FtcGFpZ25JZCA9IGdldENhbXBhaWduSWRGcm9tVXJsKCk7XG4gICAgICAgIGlmICghY2FtcGFpZ25JZCkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKFwiW0dNViBNYXggTmF2aWdhdG9yXSBObyBjYW1wYWlnbiBJRCBmb3VuZCBpbiBVUkxcIik7XG4gICAgICAgICAgICB1cGxvYWRJblByb2dyZXNzID0gZmFsc2U7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2FtcGFpZ25OYW1lID0gYXdhaXQgZ2V0Q2FtcGFpZ25OYW1lKGNhbXBhaWduSWQpO1xuICAgICAgICBpZiAoIWNhbXBhaWduTmFtZSkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKFwiW0dNViBNYXggTmF2aWdhdG9yXSBObyBjYW1wYWlnbiBuYW1lIGZvdW5kIGZvciBJRDpcIiwgY2FtcGFpZ25JZCk7XG4gICAgICAgICAgICB1cGxvYWRJblByb2dyZXNzID0gZmFsc2U7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIENhbXBhaWduIGluZm86XCIsIHsgY2FtcGFpZ25JZCwgY2FtcGFpZ25OYW1lIH0pO1xuICAgICAgICAvLyBTZW5kIHJlcXVlc3QgdG8gYmFja2dyb3VuZCBzY3JpcHQgdG8gaGFuZGxlIGRvd25sb2FkIGRldGVjdGlvbiBhbmQgdXBsb2FkXG4gICAgICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBSZXF1ZXN0aW5nIGJhY2tncm91bmQgc2NyaXB0IHRvIGNoZWNrIGRvd25sb2Fkcy4uLlwiKTtcbiAgICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICAgICAgdHlwZTogXCJDSEVDS19BTkRfVVBMT0FEX0RPV05MT0FEXCIsXG4gICAgICAgICAgICBjYW1wYWlnbk5hbWU6IGNhbXBhaWduTmFtZSxcbiAgICAgICAgICAgIGNhbXBhaWduSWQ6IGNhbXBhaWduSWQsXG4gICAgICAgIH0sIChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJbR01WIE1heCBOYXZpZ2F0b3JdIEVycm9yIHNlbmRpbmcgbWVzc2FnZSB0byBiYWNrZ3JvdW5kOlwiLCBjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpO1xuICAgICAgICAgICAgICAgIHVwbG9hZEluUHJvZ3Jlc3MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVzcG9uc2UgPT09IG51bGwgfHwgcmVzcG9uc2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlc3BvbnNlLnN1Y2Nlc3MpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gQmFja2dyb3VuZCBzY3JpcHQgcHJvY2Vzc2luZyB1cGxvYWRcIik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiW0dNViBNYXggTmF2aWdhdG9yXSBCYWNrZ3JvdW5kIHNjcmlwdCBlcnJvcjpcIiwgcmVzcG9uc2UgPT09IG51bGwgfHwgcmVzcG9uc2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlc3BvbnNlLmVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFJlc2V0IGZsYWcgYWZ0ZXIgdXBsb2FkIGNvbXBsZXRlcyAod2l0aCBkZWxheSB0byBlbnN1cmUgYmFja2dyb3VuZCBwcm9jZXNzaW5nIGZpbmlzaGVzKVxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgdXBsb2FkSW5Qcm9ncmVzcyA9IGZhbHNlO1xuICAgICAgICAgICAgfSwgNTAwMCk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIltHTVYgTWF4IE5hdmlnYXRvcl0gRXJyb3IgaW4gZGV0ZWN0QW5kVXBsb2FkRG93bmxvYWRlZEZpbGU6XCIsIGVycm9yKTtcbiAgICAgICAgdXBsb2FkSW5Qcm9ncmVzcyA9IGZhbHNlO1xuICAgIH1cbn1cbi8qKlxuICogUmV0cnkgbG9naWMgZm9yIGZpbmRpbmcgYW5kIGNsaWNraW5nIHRoZSBidXR0b25cbiAqIFRoZSBidXR0b24gbWlnaHQgbm90IGJlIGltbWVkaWF0ZWx5IGF2YWlsYWJsZSB3aGVuIHRoZSBwYWdlIGxvYWRzXG4gKi9cbmZ1bmN0aW9uIGF0dGVtcHRBdXRvQ2xpY2soYXR0ZW1wdCA9IDEpIHtcbiAgICBjb25zb2xlLmxvZyhgW0dNViBNYXggTmF2aWdhdG9yXSBBdHRlbXB0ICR7YXR0ZW1wdH0vJHtNQVhfUkVUUllfQVRURU1QVFN9IHRvIGZpbmQgZXhwb3J0IGJ1dHRvbmApO1xuICAgIGNvbnN0IGNsaWNrZWQgPSBmaW5kQW5kQ2xpY2tFeHBvcnRCdXR0b24oKTtcbiAgICBpZiAoY2xpY2tlZCkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gU3VjY2Vzc2Z1bGx5IGNsaWNrZWQgZXhwb3J0IGJ1dHRvblwiKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoYXR0ZW1wdCA8IE1BWF9SRVRSWV9BVFRFTVBUUykge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGF0dGVtcHRBdXRvQ2xpY2soYXR0ZW1wdCArIDEpLCBSRVRSWV9JTlRFUlZBTCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gTWF4IHJldHJ5IGF0dGVtcHRzIHJlYWNoZWQuIEV4cG9ydCBidXR0b24gbm90IGZvdW5kLlwiKTtcbiAgICB9XG59XG4vKipcbiAqIE5hdmlnYXRlIHRvIHRoZSBwcmV2aW91cyB1bmNvbXBsZXRlZCBjYW1wYWlnblxuICovXG5hc3luYyBmdW5jdGlvbiBnb1RvUHJldkNhbXBhaWduKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbXG4gICAgICAgICAgICBTVE9SQUdFX0tFWVMuQ0FNUEFJR05fREFUQSxcbiAgICAgICAgICAgIFNUT1JBR0VfS0VZUy5DVVJSRU5UX0lOREVYLFxuICAgICAgICAgICAgU1RPUkFHRV9LRVlTLlVQTE9BRF9TVUNDRVNTX1NUQVRVUyxcbiAgICAgICAgICAgIFNUT1JBR0VfS0VZUy5DQU1QQUlHTl9SRUdJT05TLFxuICAgICAgICAgICAgU1RPUkFHRV9LRVlTLkNBTVBBSUdOX1RZUEVTLFxuICAgICAgICAgICAgU1RPUkFHRV9LRVlTLkRBVEVfUkFOR0UsXG4gICAgICAgIF0pO1xuICAgICAgICBjb25zdCBjYW1wYWlnbnMgPSByZXN1bHRbU1RPUkFHRV9LRVlTLkNBTVBBSUdOX0RBVEFdIHx8IFtdO1xuICAgICAgICBjb25zdCBjdXJyZW50SW5kZXggPSBwYXJzZUludChyZXN1bHRbU1RPUkFHRV9LRVlTLkNVUlJFTlRfSU5ERVhdIHx8IFwiMFwiLCAxMCk7XG4gICAgICAgIGNvbnN0IHVwbG9hZFN1Y2Nlc3NTdGF0dXMgPSByZXN1bHRbU1RPUkFHRV9LRVlTLlVQTE9BRF9TVUNDRVNTX1NUQVRVU10gfHwge307XG4gICAgICAgIGNvbnN0IGNhbXBhaWduUmVnaW9ucyA9IHJlc3VsdFtTVE9SQUdFX0tFWVMuQ0FNUEFJR05fUkVHSU9OU10gfHwge307XG4gICAgICAgIGNvbnN0IGNhbXBhaWduVHlwZXMgPSByZXN1bHRbU1RPUkFHRV9LRVlTLkNBTVBBSUdOX1RZUEVTXSB8fCB7fTtcbiAgICAgICAgY29uc3QgZGF0ZVJhbmdlID0gcmVzdWx0W1NUT1JBR0VfS0VZUy5EQVRFX1JBTkdFXTtcbiAgICAgICAgaWYgKGNhbXBhaWducy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIGFsZXJ0KFwiTm8gY2FtcGFpZ25zIGF2YWlsYWJsZVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRhdGVSYW5nZSkge1xuICAgICAgICAgICAgYWxlcnQoXCJEYXRlIHJhbmdlIG5vdCBjb25maWd1cmVkLiBQbGVhc2Ugc2V0IGRhdGUgcmFuZ2UgaW4gZXh0ZW5zaW9uIHBvcHVwLlwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBGaW5kIHRoZSBwcmV2aW91cyB1bmNvbXBsZXRlZCBjYW1wYWlnblxuICAgICAgICBsZXQgcHJldkluZGV4ID0gY3VycmVudEluZGV4IC0gMTtcbiAgICAgICAgbGV0IGZvdW5kUHJldiA9IGZhbHNlO1xuICAgICAgICAvLyBTZWFyY2ggYmFja3dhcmQgZnJvbSBjdXJyZW50IHBvc2l0aW9uXG4gICAgICAgIGZvciAobGV0IGkgPSBwcmV2SW5kZXg7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICBjb25zdCBjYW1wYWlnbiA9IGNhbXBhaWduc1tpXTtcbiAgICAgICAgICAgIGNvbnN0IHVwbG9hZFN0YXR1cyA9IHVwbG9hZFN1Y2Nlc3NTdGF0dXNbY2FtcGFpZ24ubmFtZV07XG4gICAgICAgICAgICAvLyBTa2lwIGNvbXBsZXRlZCBjYW1wYWlnbnNcbiAgICAgICAgICAgIGlmICghdXBsb2FkU3RhdHVzIHx8IHVwbG9hZFN0YXR1cy5zdGF0dXMgIT09IFwic3VjY2Vzc1wiKSB7XG4gICAgICAgICAgICAgICAgcHJldkluZGV4ID0gaTtcbiAgICAgICAgICAgICAgICBmb3VuZFByZXYgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIElmIG5vIHVuY29tcGxldGVkIGNhbXBhaWduIGZvdW5kIGJlZm9yZSwgd3JhcCBhcm91bmQgdG8gZW5kXG4gICAgICAgIGlmICghZm91bmRQcmV2KSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gY2FtcGFpZ25zLmxlbmd0aCAtIDE7IGkgPj0gY3VycmVudEluZGV4OyBpLS0pIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjYW1wYWlnbiA9IGNhbXBhaWduc1tpXTtcbiAgICAgICAgICAgICAgICBjb25zdCB1cGxvYWRTdGF0dXMgPSB1cGxvYWRTdWNjZXNzU3RhdHVzW2NhbXBhaWduLm5hbWVdO1xuICAgICAgICAgICAgICAgIGlmICghdXBsb2FkU3RhdHVzIHx8IHVwbG9hZFN0YXR1cy5zdGF0dXMgIT09IFwic3VjY2Vzc1wiKSB7XG4gICAgICAgICAgICAgICAgICAgIHByZXZJbmRleCA9IGk7XG4gICAgICAgICAgICAgICAgICAgIGZvdW5kUHJldiA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWZvdW5kUHJldikge1xuICAgICAgICAgICAgYWxlcnQoXCJBbGwgY2FtcGFpZ25zIGNvbXBsZXRlZCEg8J+OiVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBOYXZpZ2F0ZSB0byBwcmV2aW91cyBjYW1wYWlnbiB3aXRoIHByb3BlciBVUkwgYnVpbGRpbmdcbiAgICAgICAgY29uc3QgY2FtcGFpZ24gPSBjYW1wYWlnbnNbcHJldkluZGV4XTtcbiAgICAgICAgY29uc3QgcmVnaW9uID0gY2FtcGFpZ25SZWdpb25zW2NhbXBhaWduLmlkXTtcbiAgICAgICAgaWYgKCFyZWdpb24pIHtcbiAgICAgICAgICAgIGFsZXJ0KGBQbGVhc2Ugc2VsZWN0IGEgcmVnaW9uIGZvciBjYW1wYWlnbjogJHtjYW1wYWlnbi5uYW1lfWApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIENhbGN1bGF0ZSB0aW1lc3RhbXBzIGJhc2VkIG9uIHJlZ2lvblxuICAgICAgICBjb25zdCBzdGFydFRpbWVzdGFtcCA9IHJlZ2lvbkRhdGVUb1RpbWVzdGFtcChyZWdpb24sIGRhdGVSYW5nZS5zdGFydFllYXIsIGRhdGVSYW5nZS5zdGFydE1vbnRoLCBkYXRlUmFuZ2Uuc3RhcnREYXkpO1xuICAgICAgICBjb25zdCBlbmRUaW1lc3RhbXAgPSByZWdpb25EYXRlVG9UaW1lc3RhbXAocmVnaW9uLCBkYXRlUmFuZ2UuZW5kWWVhciwgZGF0ZVJhbmdlLmVuZE1vbnRoLCBkYXRlUmFuZ2UuZW5kRGF5KTtcbiAgICAgICAgLy8gR2V0IGNhbXBhaWduIHR5cGUgKGRlZmF1bHQgdG8gUFJPRFVDVCBpZiBub3Qgc2V0KVxuICAgICAgICBjb25zdCBjYW1wYWlnblR5cGUgPSBjYW1wYWlnblR5cGVzW2NhbXBhaWduLmlkXSB8fCBcIlBST0RVQ1RcIjtcbiAgICAgICAgLy8gQnVpbGQgdGhlIGNhbXBhaWduIFVSTFxuICAgICAgICBjb25zdCBuZXdVcmwgPSBidWlsZENhbXBhaWduVXJsKHJlZ2lvbiwgY2FtcGFpZ24uaWQsIHN0YXJ0VGltZXN0YW1wLCBlbmRUaW1lc3RhbXAsIGNhbXBhaWduVHlwZSk7XG4gICAgICAgIC8vIFVwZGF0ZSBjdXJyZW50IGluZGV4XG4gICAgICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ1VSUkVOVF9JTkRFWF06IHByZXZJbmRleC50b1N0cmluZygpIH0pO1xuICAgICAgICBjb25zb2xlLmxvZyhgW0dNViBNYXggTmF2aWdhdG9yXSBOYXZpZ2F0aW5nIHRvIHByZXZpb3VzIGNhbXBhaWduOiAke2NhbXBhaWduLm5hbWV9YCk7XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gbmV3VXJsO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIltHTVYgTWF4IE5hdmlnYXRvcl0gRXJyb3IgbmF2aWdhdGluZyB0byBwcmV2aW91cyBjYW1wYWlnbjpcIiwgZXJyb3IpO1xuICAgICAgICBhbGVydChcIkZhaWxlZCB0byBuYXZpZ2F0ZSB0byBwcmV2aW91cyBjYW1wYWlnblwiKTtcbiAgICB9XG59XG4vKipcbiAqIE5hdmlnYXRlIHRvIHRoZSBmaXJzdCB1bmNvbXBsZXRlZCBjYW1wYWlnbiBpbiB0aGUgbGlzdFxuICovXG5hc3luYyBmdW5jdGlvbiBnb1RvRmlyc3RDYW1wYWlnbigpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICAgICAgU1RPUkFHRV9LRVlTLkNBTVBBSUdOX0RBVEEsXG4gICAgICAgICAgICBTVE9SQUdFX0tFWVMuVVBMT0FEX1NVQ0NFU1NfU1RBVFVTLFxuICAgICAgICAgICAgU1RPUkFHRV9LRVlTLkNBTVBBSUdOX1JFR0lPTlMsXG4gICAgICAgICAgICBTVE9SQUdFX0tFWVMuQ0FNUEFJR05fVFlQRVMsXG4gICAgICAgICAgICBTVE9SQUdFX0tFWVMuREFURV9SQU5HRSxcbiAgICAgICAgXSk7XG4gICAgICAgIGNvbnN0IGNhbXBhaWducyA9IHJlc3VsdFtTVE9SQUdFX0tFWVMuQ0FNUEFJR05fREFUQV0gfHwgW107XG4gICAgICAgIGNvbnN0IHVwbG9hZFN1Y2Nlc3NTdGF0dXMgPSByZXN1bHRbU1RPUkFHRV9LRVlTLlVQTE9BRF9TVUNDRVNTX1NUQVRVU10gfHwge307XG4gICAgICAgIGNvbnN0IGNhbXBhaWduUmVnaW9ucyA9IHJlc3VsdFtTVE9SQUdFX0tFWVMuQ0FNUEFJR05fUkVHSU9OU10gfHwge307XG4gICAgICAgIGNvbnN0IGNhbXBhaWduVHlwZXMgPSByZXN1bHRbU1RPUkFHRV9LRVlTLkNBTVBBSUdOX1RZUEVTXSB8fCB7fTtcbiAgICAgICAgY29uc3QgZGF0ZVJhbmdlID0gcmVzdWx0W1NUT1JBR0VfS0VZUy5EQVRFX1JBTkdFXTtcbiAgICAgICAgaWYgKGNhbXBhaWducy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIGFsZXJ0KFwiTm8gY2FtcGFpZ25zIGF2YWlsYWJsZVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRhdGVSYW5nZSkge1xuICAgICAgICAgICAgYWxlcnQoXCJEYXRlIHJhbmdlIG5vdCBjb25maWd1cmVkLiBQbGVhc2Ugc2V0IGRhdGUgcmFuZ2UgaW4gZXh0ZW5zaW9uIHBvcHVwLlwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBGaW5kIHRoZSBmaXJzdCB1bmNvbXBsZXRlZCBjYW1wYWlnblxuICAgICAgICBsZXQgZmlyc3RJbmRleCA9IC0xO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNhbXBhaWducy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgY2FtcGFpZ24gPSBjYW1wYWlnbnNbaV07XG4gICAgICAgICAgICBjb25zdCB1cGxvYWRTdGF0dXMgPSB1cGxvYWRTdWNjZXNzU3RhdHVzW2NhbXBhaWduLm5hbWVdO1xuICAgICAgICAgICAgLy8gU2tpcCBjb21wbGV0ZWQgY2FtcGFpZ25zXG4gICAgICAgICAgICBpZiAoIXVwbG9hZFN0YXR1cyB8fCB1cGxvYWRTdGF0dXMuc3RhdHVzICE9PSBcInN1Y2Nlc3NcIikge1xuICAgICAgICAgICAgICAgIGZpcnN0SW5kZXggPSBpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChmaXJzdEluZGV4ID09PSAtMSkge1xuICAgICAgICAgICAgYWxlcnQoXCJBbGwgY2FtcGFpZ25zIGNvbXBsZXRlZCEg8J+OiVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBOYXZpZ2F0ZSB0byBmaXJzdCB1bmNvbXBsZXRlZCBjYW1wYWlnbiB3aXRoIHByb3BlciBVUkwgYnVpbGRpbmdcbiAgICAgICAgY29uc3QgY2FtcGFpZ24gPSBjYW1wYWlnbnNbZmlyc3RJbmRleF07XG4gICAgICAgIGNvbnN0IHJlZ2lvbiA9IGNhbXBhaWduUmVnaW9uc1tjYW1wYWlnbi5pZF07XG4gICAgICAgIGlmICghcmVnaW9uKSB7XG4gICAgICAgICAgICBhbGVydChgUGxlYXNlIHNlbGVjdCBhIHJlZ2lvbiBmb3IgY2FtcGFpZ246ICR7Y2FtcGFpZ24ubmFtZX1gKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBDYWxjdWxhdGUgdGltZXN0YW1wcyBiYXNlZCBvbiByZWdpb25cbiAgICAgICAgY29uc3Qgc3RhcnRUaW1lc3RhbXAgPSByZWdpb25EYXRlVG9UaW1lc3RhbXAocmVnaW9uLCBkYXRlUmFuZ2Uuc3RhcnRZZWFyLCBkYXRlUmFuZ2Uuc3RhcnRNb250aCwgZGF0ZVJhbmdlLnN0YXJ0RGF5KTtcbiAgICAgICAgY29uc3QgZW5kVGltZXN0YW1wID0gcmVnaW9uRGF0ZVRvVGltZXN0YW1wKHJlZ2lvbiwgZGF0ZVJhbmdlLmVuZFllYXIsIGRhdGVSYW5nZS5lbmRNb250aCwgZGF0ZVJhbmdlLmVuZERheSk7XG4gICAgICAgIC8vIEdldCBjYW1wYWlnbiB0eXBlIChkZWZhdWx0IHRvIFBST0RVQ1QgaWYgbm90IHNldClcbiAgICAgICAgY29uc3QgY2FtcGFpZ25UeXBlID0gY2FtcGFpZ25UeXBlc1tjYW1wYWlnbi5pZF0gfHwgXCJQUk9EVUNUXCI7XG4gICAgICAgIC8vIEJ1aWxkIHRoZSBjYW1wYWlnbiBVUkxcbiAgICAgICAgY29uc3QgbmV3VXJsID0gYnVpbGRDYW1wYWlnblVybChyZWdpb24sIGNhbXBhaWduLmlkLCBzdGFydFRpbWVzdGFtcCwgZW5kVGltZXN0YW1wLCBjYW1wYWlnblR5cGUpO1xuICAgICAgICAvLyBVcGRhdGUgY3VycmVudCBpbmRleFxuICAgICAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU1RPUkFHRV9LRVlTLkNVUlJFTlRfSU5ERVhdOiBmaXJzdEluZGV4LnRvU3RyaW5nKCkgfSk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBbR01WIE1heCBOYXZpZ2F0b3JdIE5hdmlnYXRpbmcgdG8gZmlyc3QgY2FtcGFpZ246ICR7Y2FtcGFpZ24ubmFtZX1gKTtcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBuZXdVcmw7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiW0dNViBNYXggTmF2aWdhdG9yXSBFcnJvciBuYXZpZ2F0aW5nIHRvIGZpcnN0IGNhbXBhaWduOlwiLCBlcnJvcik7XG4gICAgICAgIGFsZXJ0KFwiRmFpbGVkIHRvIG5hdmlnYXRlIHRvIGZpcnN0IGNhbXBhaWduXCIpO1xuICAgIH1cbn1cbi8qKlxuICogTmF2aWdhdGUgdG8gdGhlIG5leHQgdW5jb21wbGV0ZWQgY2FtcGFpZ25cbiAqL1xuYXN5bmMgZnVuY3Rpb24gZ29Ub05leHRDYW1wYWlnbigpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICAgICAgU1RPUkFHRV9LRVlTLkNBTVBBSUdOX0RBVEEsXG4gICAgICAgICAgICBTVE9SQUdFX0tFWVMuQ1VSUkVOVF9JTkRFWCxcbiAgICAgICAgICAgIFNUT1JBR0VfS0VZUy5VUExPQURfU1VDQ0VTU19TVEFUVVMsXG4gICAgICAgICAgICBTVE9SQUdFX0tFWVMuQ0FNUEFJR05fUkVHSU9OUyxcbiAgICAgICAgICAgIFNUT1JBR0VfS0VZUy5DQU1QQUlHTl9UWVBFUyxcbiAgICAgICAgICAgIFNUT1JBR0VfS0VZUy5EQVRFX1JBTkdFLFxuICAgICAgICBdKTtcbiAgICAgICAgY29uc3QgY2FtcGFpZ25zID0gcmVzdWx0W1NUT1JBR0VfS0VZUy5DQU1QQUlHTl9EQVRBXSB8fCBbXTtcbiAgICAgICAgY29uc3QgY3VycmVudEluZGV4ID0gcGFyc2VJbnQocmVzdWx0W1NUT1JBR0VfS0VZUy5DVVJSRU5UX0lOREVYXSB8fCBcIjBcIiwgMTApO1xuICAgICAgICBjb25zdCB1cGxvYWRTdWNjZXNzU3RhdHVzID0gcmVzdWx0W1NUT1JBR0VfS0VZUy5VUExPQURfU1VDQ0VTU19TVEFUVVNdIHx8IHt9O1xuICAgICAgICBjb25zdCBjYW1wYWlnblJlZ2lvbnMgPSByZXN1bHRbU1RPUkFHRV9LRVlTLkNBTVBBSUdOX1JFR0lPTlNdIHx8IHt9O1xuICAgICAgICBjb25zdCBjYW1wYWlnblR5cGVzID0gcmVzdWx0W1NUT1JBR0VfS0VZUy5DQU1QQUlHTl9UWVBFU10gfHwge307XG4gICAgICAgIGNvbnN0IGRhdGVSYW5nZSA9IHJlc3VsdFtTVE9SQUdFX0tFWVMuREFURV9SQU5HRV07XG4gICAgICAgIGlmIChjYW1wYWlnbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBhbGVydChcIk5vIGNhbXBhaWducyBhdmFpbGFibGVcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFkYXRlUmFuZ2UpIHtcbiAgICAgICAgICAgIGFsZXJ0KFwiRGF0ZSByYW5nZSBub3QgY29uZmlndXJlZC4gUGxlYXNlIHNldCBkYXRlIHJhbmdlIGluIGV4dGVuc2lvbiBwb3B1cC5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gRmluZCB0aGUgbmV4dCB1bmNvbXBsZXRlZCBjYW1wYWlnblxuICAgICAgICBsZXQgbmV4dEluZGV4ID0gY3VycmVudEluZGV4ICsgMTtcbiAgICAgICAgbGV0IGZvdW5kTmV4dCA9IGZhbHNlO1xuICAgICAgICAvLyBTZWFyY2ggZm9yd2FyZCBmcm9tIGN1cnJlbnQgcG9zaXRpb25cbiAgICAgICAgZm9yIChsZXQgaSA9IG5leHRJbmRleDsgaSA8IGNhbXBhaWducy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgY2FtcGFpZ24gPSBjYW1wYWlnbnNbaV07XG4gICAgICAgICAgICBjb25zdCB1cGxvYWRTdGF0dXMgPSB1cGxvYWRTdWNjZXNzU3RhdHVzW2NhbXBhaWduLm5hbWVdO1xuICAgICAgICAgICAgLy8gU2tpcCBjb21wbGV0ZWQgY2FtcGFpZ25zXG4gICAgICAgICAgICBpZiAoIXVwbG9hZFN0YXR1cyB8fCB1cGxvYWRTdGF0dXMuc3RhdHVzICE9PSBcInN1Y2Nlc3NcIikge1xuICAgICAgICAgICAgICAgIG5leHRJbmRleCA9IGk7XG4gICAgICAgICAgICAgICAgZm91bmROZXh0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBJZiBubyB1bmNvbXBsZXRlZCBjYW1wYWlnbiBmb3VuZCBhaGVhZCwgd3JhcCBhcm91bmQgdG8gYmVnaW5uaW5nXG4gICAgICAgIGlmICghZm91bmROZXh0KSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8PSBjdXJyZW50SW5kZXg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNhbXBhaWduID0gY2FtcGFpZ25zW2ldO1xuICAgICAgICAgICAgICAgIGNvbnN0IHVwbG9hZFN0YXR1cyA9IHVwbG9hZFN1Y2Nlc3NTdGF0dXNbY2FtcGFpZ24ubmFtZV07XG4gICAgICAgICAgICAgICAgaWYgKCF1cGxvYWRTdGF0dXMgfHwgdXBsb2FkU3RhdHVzLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgbmV4dEluZGV4ID0gaTtcbiAgICAgICAgICAgICAgICAgICAgZm91bmROZXh0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICghZm91bmROZXh0KSB7XG4gICAgICAgICAgICBhbGVydChcIkFsbCBjYW1wYWlnbnMgY29tcGxldGVkISDwn46JXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIE5hdmlnYXRlIHRvIG5leHQgY2FtcGFpZ24gd2l0aCBwcm9wZXIgVVJMIGJ1aWxkaW5nXG4gICAgICAgIGNvbnN0IGNhbXBhaWduID0gY2FtcGFpZ25zW25leHRJbmRleF07XG4gICAgICAgIGNvbnN0IHJlZ2lvbiA9IGNhbXBhaWduUmVnaW9uc1tjYW1wYWlnbi5pZF07XG4gICAgICAgIGlmICghcmVnaW9uKSB7XG4gICAgICAgICAgICBhbGVydChgUGxlYXNlIHNlbGVjdCBhIHJlZ2lvbiBmb3IgY2FtcGFpZ246ICR7Y2FtcGFpZ24ubmFtZX1gKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBDYWxjdWxhdGUgdGltZXN0YW1wcyBiYXNlZCBvbiByZWdpb25cbiAgICAgICAgY29uc3Qgc3RhcnRUaW1lc3RhbXAgPSByZWdpb25EYXRlVG9UaW1lc3RhbXAocmVnaW9uLCBkYXRlUmFuZ2Uuc3RhcnRZZWFyLCBkYXRlUmFuZ2Uuc3RhcnRNb250aCwgZGF0ZVJhbmdlLnN0YXJ0RGF5KTtcbiAgICAgICAgY29uc3QgZW5kVGltZXN0YW1wID0gcmVnaW9uRGF0ZVRvVGltZXN0YW1wKHJlZ2lvbiwgZGF0ZVJhbmdlLmVuZFllYXIsIGRhdGVSYW5nZS5lbmRNb250aCwgZGF0ZVJhbmdlLmVuZERheSk7XG4gICAgICAgIC8vIEdldCBjYW1wYWlnbiB0eXBlIChkZWZhdWx0IHRvIFBST0RVQ1QgaWYgbm90IHNldClcbiAgICAgICAgY29uc3QgY2FtcGFpZ25UeXBlID0gY2FtcGFpZ25UeXBlc1tjYW1wYWlnbi5pZF0gfHwgXCJQUk9EVUNUXCI7XG4gICAgICAgIC8vIEJ1aWxkIHRoZSBjYW1wYWlnbiBVUkxcbiAgICAgICAgY29uc3QgbmV3VXJsID0gYnVpbGRDYW1wYWlnblVybChyZWdpb24sIGNhbXBhaWduLmlkLCBzdGFydFRpbWVzdGFtcCwgZW5kVGltZXN0YW1wLCBjYW1wYWlnblR5cGUpO1xuICAgICAgICAvLyBVcGRhdGUgY3VycmVudCBpbmRleFxuICAgICAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU1RPUkFHRV9LRVlTLkNVUlJFTlRfSU5ERVhdOiBuZXh0SW5kZXgudG9TdHJpbmcoKSB9KTtcbiAgICAgICAgY29uc29sZS5sb2coYFtHTVYgTWF4IE5hdmlnYXRvcl0gTmF2aWdhdGluZyB0byBuZXh0IGNhbXBhaWduOiAke2NhbXBhaWduLm5hbWV9YCk7XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gbmV3VXJsO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIltHTVYgTWF4IE5hdmlnYXRvcl0gRXJyb3IgbmF2aWdhdGluZyB0byBuZXh0IGNhbXBhaWduOlwiLCBlcnJvcik7XG4gICAgICAgIGFsZXJ0KFwiRmFpbGVkIHRvIG5hdmlnYXRlIHRvIG5leHQgY2FtcGFpZ25cIik7XG4gICAgfVxufVxuLyoqXG4gKiBVcGRhdGUgdXBsb2FkIHN0YXR1cyB0b2FzdCB3aXRoIGN1cnJlbnQgc3RhdHVzXG4gKi9cbmZ1bmN0aW9uIHVwZGF0ZVVwbG9hZFN0YXR1c1RvYXN0KHN0YXR1cywgbWVzc2FnZSkge1xuICAgIGNvbnN0IHRvYXN0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnbXYtbWF4LXVwbG9hZC1zdGF0dXMtdG9hc3RcIik7XG4gICAgaWYgKCF0b2FzdClcbiAgICAgICAgcmV0dXJuO1xuICAgIC8vIFVwZGF0ZSBzdGF0dXMgY2xhc3NcbiAgICB0b2FzdC5jbGFzc05hbWUgPSBgZ212LW1heC11cGxvYWQtc3RhdHVzLXRvYXN0IGdtdi1tYXgtdXBsb2FkLXN0YXR1cy0ke3N0YXR1c31gO1xuICAgIC8vIFVwZGF0ZSBpY29uIGFuZCBtZXNzYWdlXG4gICAgbGV0IGljb24gPSBcIlwiO1xuICAgIGxldCB0ZXh0ID0gXCJcIjtcbiAgICBzd2l0Y2ggKHN0YXR1cykge1xuICAgICAgICBjYXNlIFwiaWRsZVwiOlxuICAgICAgICAgICAgdG9hc3Quc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjYXNlIFwidXBsb2FkaW5nXCI6XG4gICAgICAgICAgICBpY29uID0gYDxzdmcgY2xhc3M9XCJnbXYtbWF4LXN0YXR1cy1zcGlubmVyXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPVwiMThcIiBoZWlnaHQ9XCIxOFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIj5cbiAgICAgICAgPHBhdGggZD1cIk0yMSAxMmE5IDkgMCAxIDEtNi4yMTktOC41NlwiLz5cbiAgICAgIDwvc3ZnPmA7XG4gICAgICAgICAgICB0ZXh0ID0gbWVzc2FnZSB8fCBcIuyXheuhnOuTnCDspJEuLi5cIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwic3VjY2Vzc1wiOlxuICAgICAgICAgICAgaWNvbiA9IGA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD1cIjE4XCIgaGVpZ2h0PVwiMThcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2Utd2lkdGg9XCIyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCI+XG4gICAgICAgIDxwYXRoIGQ9XCJNMjIgMTEuMDhWMTJhMTAgMTAgMCAxIDEtNS45My05LjE0XCI+PC9wYXRoPlxuICAgICAgICA8cG9seWxpbmUgcG9pbnRzPVwiMjIgNCAxMiAxNC4wMSA5IDExLjAxXCI+PC9wb2x5bGluZT5cbiAgICAgIDwvc3ZnPmA7XG4gICAgICAgICAgICB0ZXh0ID0gbWVzc2FnZSB8fCBcIuyXheuhnOuTnCDsmYTro4whXCI7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcImVycm9yXCI6XG4gICAgICAgICAgICBpY29uID0gYDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPVwiMThcIiBoZWlnaHQ9XCIxOFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIj5cbiAgICAgICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIxMFwiPjwvY2lyY2xlPlxuICAgICAgICA8bGluZSB4MT1cIjE1XCIgeTE9XCI5XCIgeDI9XCI5XCIgeTI9XCIxNVwiPjwvbGluZT5cbiAgICAgICAgPGxpbmUgeDE9XCI5XCIgeTE9XCI5XCIgeDI9XCIxNVwiIHkyPVwiMTVcIj48L2xpbmU+XG4gICAgICA8L3N2Zz5gO1xuICAgICAgICAgICAgdGV4dCA9IG1lc3NhZ2UgfHwgXCLsl4XroZzrk5wg7Iuk7YyoXCI7XG4gICAgICAgICAgICBicmVhaztcbiAgICB9XG4gICAgdG9hc3QuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJnbXYtbWF4LXN0YXR1cy1jb250ZW50XCI+XG4gICAgICAke2ljb259XG4gICAgICA8c3Bhbj4ke3RleHR9PC9zcGFuPlxuICAgIDwvZGl2PlxuICBgO1xuICAgIHRvYXN0LnN0eWxlLmRpc3BsYXkgPSBcImZsZXhcIjtcbiAgICAvLyBBdXRvLWhpZGUgc3VjY2Vzcy9lcnJvciBtZXNzYWdlcyBhZnRlciA1IHNlY29uZHNcbiAgICBpZiAoc3RhdHVzID09PSBcInN1Y2Nlc3NcIiB8fCBzdGF0dXMgPT09IFwiZXJyb3JcIikge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRvYXN0LnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgfSwgNTAwMCk7XG4gICAgfVxufVxuLyoqXG4gKiBJbmplY3Qgc3RhdHVzIHRvYXN0IGVsZW1lbnQgYWJvdmUgdGhlIE5leHQgQ2FtcGFpZ24gYnV0dG9uXG4gKiBBbHdheXMgdmlzaWJsZSBidXQgbWF5IHNob3cgZGlmZmVyZW50IHN0YXRlcyBiYXNlZCBvbiBjb25maWd1cmF0aW9uXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGluamVjdFVwbG9hZFN0YXR1c1RvYXN0KCkge1xuICAgIC8vIENoZWNrIGlmIHRvYXN0IGFscmVhZHkgZXhpc3RzXG4gICAgaWYgKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZ212LW1heC11cGxvYWQtc3RhdHVzLXRvYXN0XCIpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gQ3JlYXRlIHRvYXN0IGVsZW1lbnRcbiAgICBjb25zdCB0b2FzdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgdG9hc3QuaWQgPSBcImdtdi1tYXgtdXBsb2FkLXN0YXR1cy10b2FzdFwiO1xuICAgIHRvYXN0LmNsYXNzTmFtZSA9IFwiZ212LW1heC11cGxvYWQtc3RhdHVzLXRvYXN0IGdtdi1tYXgtdXBsb2FkLXN0YXR1cy1pZGxlXCI7XG4gICAgLy8gQWRkIHN0eWxlcyB1c2luZyBhIHN0eWxlIHRhZyBmb3IgYW5pbWF0aW9ucyBhbmQgY29tcGxleCBzZWxlY3RvcnNcbiAgICBjb25zdCBzdHlsZVRhZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzdHlsZVwiKTtcbiAgICBzdHlsZVRhZy50ZXh0Q29udGVudCA9IGBcbiAgICAuZ212LW1heC11cGxvYWQtc3RhdHVzLXRvYXN0IHtcbiAgICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICAgIGJvdHRvbTogMTg0cHg7XG4gICAgICByaWdodDogMzJweDtcbiAgICAgIHotaW5kZXg6IDEwMDAwO1xuICAgICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbiAgICAgIGJveC1zaGFkb3c6IDAuMnJlbSAwLjJyZW0gMCAwIGJsYWNrO1xuICAgICAgcGFkZGluZzogMTJweCAyMHB4O1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgZ2FwOiA4cHg7XG4gICAgICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBjdWJpYy1iZXppZXIoMC40LCAwLCAwLjIsIDEpO1xuICAgICAgd2lkdGg6IDE1MHB4O1xuICAgIH1cblxuICAgIC5nbXYtbWF4LXN0YXR1cy1jb250ZW50IHtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgZ2FwOiAxMHB4O1xuICAgIH1cblxuICAgIC5nbXYtbWF4LXVwbG9hZC1zdGF0dXMtdXBsb2FkaW5nIHtcbiAgICAgIGJhY2tncm91bmQ6ICNlZmY2ZmY7XG4gICAgICBib3JkZXItY29sb3I6ICMzYjgyZjY7XG4gICAgICBjb2xvcjogIzFlNDBhZjtcbiAgICB9XG5cbiAgICAuZ212LW1heC11cGxvYWQtc3RhdHVzLXN1Y2Nlc3Mge1xuICAgICAgYmFja2dyb3VuZDogI2YwZmRmNDtcbiAgICAgIGJvcmRlci1jb2xvcjogIzIyYzU1ZTtcbiAgICAgIGNvbG9yOiAjMTU4MDNkO1xuICAgIH1cblxuICAgIC5nbXYtbWF4LXVwbG9hZC1zdGF0dXMtZXJyb3Ige1xuICAgICAgYmFja2dyb3VuZDogI2ZlZjJmMjtcbiAgICAgIGJvcmRlci1jb2xvcjogI2VmNDQ0NDtcbiAgICAgIGNvbG9yOiAjOTkxYjFiO1xuICAgIH1cblxuICAgIC5nbXYtbWF4LXN0YXR1cy1zcGlubmVyIHtcbiAgICAgIGFuaW1hdGlvbjogZ212LW1heC1zcGluIDFzIGxpbmVhciBpbmZpbml0ZTtcbiAgICB9XG5cbiAgICBAa2V5ZnJhbWVzIGdtdi1tYXgtc3BpbiB7XG4gICAgICBmcm9tIHtcbiAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XG4gICAgICB9XG4gICAgICB0byB7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7XG4gICAgICB9XG4gICAgfVxuICBgO1xuICAgIC8vIEluamVjdCBzdHlsZXMgYW5kIHRvYXN0XG4gICAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzdHlsZVRhZyk7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0b2FzdCk7XG4gICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIFVwbG9hZCBzdGF0dXMgdG9hc3QgaW5qZWN0ZWRcIik7XG59XG4vKipcbiAqIEluamVjdCBhIGRhdGUgZGlzcGxheSBib3ggc2hvd2luZyB0aGUgY29uZmlndXJlZCBkYXRlIHJhbmdlXG4gKiBQb3NpdGlvbmVkIGFib3ZlIHRoZSBwcm9ncmVzcyB0b2FzdFxuICovXG5hc3luYyBmdW5jdGlvbiBpbmplY3REYXRlRGlzcGxheUJveCgpIHtcbiAgICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnbXYtbWF4LWRhdGUtZGlzcGxheVwiKSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGRhdGVCb3ggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIGRhdGVCb3guaWQgPSBcImdtdi1tYXgtZGF0ZS1kaXNwbGF5XCI7XG4gICAgZGF0ZUJveC5jbGFzc05hbWUgPSBcImdtdi1tYXgtZGF0ZS1kaXNwbGF5XCI7XG4gICAgZGF0ZUJveC5zdHlsZS5jc3NUZXh0ID0gYFxuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBib3R0b206IDIzOHB4OyAvKiBhYm92ZSBwcm9ncmVzcyB0b2FzdCAoMTMwcHgpIGFuZCB1cGxvYWQgdG9hc3QgKDE4NHB4KSAqL1xuICAgIHJpZ2h0OiAzMnB4O1xuICAgIHotaW5kZXg6IDEwMDAwO1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xuICAgIGJveC1zaGFkb3c6IDAuMnJlbSAwLjJyZW0gMCAwIGJsYWNrO1xuICAgIHBhZGRpbmc6IDEwcHggMTRweDtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgZ2FwOiA4cHg7XG4gICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgJ1NlZ29lIFVJJywgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIHdpZHRoOiAxNTBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGA7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChkYXRlQm94KTtcbiAgICBhd2FpdCB1cGRhdGVEYXRlRGlzcGxheSgpO1xuICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBEYXRlIGRpc3BsYXkgYm94IGluamVjdGVkXCIpO1xufVxuLyoqXG4gKiBVcGRhdGUgdGhlIGRhdGUgZGlzcGxheSBib3ggd2l0aCBjdXJyZW50IGNvbmZpZ3VyZWQgZGF0ZSByYW5nZVxuICovXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVEYXRlRGlzcGxheSgpIHtcbiAgICBjb25zdCBkYXRlQm94ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnbXYtbWF4LWRhdGUtZGlzcGxheVwiKTtcbiAgICBpZiAoIWRhdGVCb3gpXG4gICAgICAgIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1wiZ212X21heF9kYXRlX3JhbmdlXCJdKTtcbiAgICAgICAgY29uc3QgZGF0ZVJhbmdlID0gcmVzdWx0Lmdtdl9tYXhfZGF0ZV9yYW5nZTtcbiAgICAgICAgaWYgKGRhdGVSYW5nZSkge1xuICAgICAgICAgICAgY29uc3Qgc3RhcnREYXRlID0gYCR7ZGF0ZVJhbmdlLnN0YXJ0RGF5fS4ke1N0cmluZyhkYXRlUmFuZ2Uuc3RhcnRNb250aCkucGFkU3RhcnQoMiwgJzAnKX1gO1xuICAgICAgICAgICAgY29uc3QgZW5kRGF0ZSA9IGAke2RhdGVSYW5nZS5lbmREYXl9LiR7U3RyaW5nKGRhdGVSYW5nZS5lbmRNb250aCkucGFkU3RhcnQoMiwgJzAnKX1gO1xuICAgICAgICAgICAgZGF0ZUJveC50ZXh0Q29udGVudCA9IGAke3N0YXJ0RGF0ZX0gLSAke2VuZERhdGV9YDtcbiAgICAgICAgICAgIGRhdGVCb3guc3R5bGUuZGlzcGxheSA9IFwiZmxleFwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgZGF0ZUJveC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgZGF0ZUJveC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgfVxufVxuLyoqXG4gKiBJbmplY3QgYSBwZXJtYW5lbnQgcHJvZ3Jlc3MgdG9hc3Qgc2hvd2luZyB1cGxvYWRlZC90b3RhbCBjYW1wYWlnbnNcbiAqIFBvc2l0aW9uZWQgYmV0d2VlbiB0aGUgdXBsb2FkIHN0YXR1cyB0b2FzdCBhbmQgdGhlIGNvbnRyb2wgYnV0dG9uc1xuICovXG5hc3luYyBmdW5jdGlvbiBpbmplY3RQcm9ncmVzc1RvYXN0KCkge1xuICAgIGlmIChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImdtdi1tYXgtcHJvZ3Jlc3MtdG9hc3RcIikpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB0b2FzdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgdG9hc3QuaWQgPSBcImdtdi1tYXgtcHJvZ3Jlc3MtdG9hc3RcIjtcbiAgICB0b2FzdC5jbGFzc05hbWUgPSBcImdtdi1tYXgtcHJvZ3Jlc3MtdG9hc3RcIjtcbiAgICB0b2FzdC5zdHlsZS5jc3NUZXh0ID0gYFxuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBib3R0b206IDEzMHB4OyAvKiBiZXR3ZWVuIHVwbG9hZCB0b2FzdCAoMTUwcHgpIGFuZCBidXR0b25zICg4NXB4KSAqL1xuICAgIHJpZ2h0OiAzMnB4O1xuICAgIHotaW5kZXg6IDEwMDAwO1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xuICAgIGJveC1zaGFkb3c6IDAuMnJlbSAwLjJyZW0gMCAwIGJsYWNrO1xuICAgIHBhZGRpbmc6IDEwcHggMTRweDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgZ2FwOiA4cHg7XG4gICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgJ1NlZ29lIFVJJywgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIHdpZHRoOiAxNTBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICBgO1xuICAgIC8vIENyZWF0ZSByZWZldGNoIGJ1dHRvbiAoYWx3YXlzIHZpc2libGUgbmV4dCB0byBjYW1wYWlnbiBudW1iZXIpXG4gICAgY29uc3QgcmVmZXRjaEJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIik7XG4gICAgcmVmZXRjaEJ0bi5pZCA9IFwiZ212LW1heC1yZWZldGNoLWJ0blwiO1xuICAgIHJlZmV0Y2hCdG4uY2xhc3NOYW1lID0gXCJnbXYtbWF4LXJlZmV0Y2gtYnRuXCI7XG4gICAgcmVmZXRjaEJ0bi5pbm5lckhUTUwgPSBgXG4gICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIxNFwiIGhlaWdodD1cIjE0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiPlxuICAgICAgPHBhdGggZD1cIk0yMS41IDJ2NmgtNk0yLjUgMjJ2LTZoNk0yIDExLjVhMTAgMTAgMCAwIDEgMTguOC00LjNNMjIgMTIuNWExMCAxMCAwIDAgMS0xOC44IDQuMlwiLz5cbiAgICA8L3N2Zz5cbiAgYDtcbiAgICByZWZldGNoQnRuLnN0eWxlLmNzc1RleHQgPSBgXG4gICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBtYXJnaW4tbGVmdDogNXB4O1xuICAgIHBhZGRpbmc6IDRweDtcbiAgICB3aWR0aDogMjRweDtcbiAgICBoZWlnaHQ6IDI0cHg7XG4gICAgYm9yZGVyOiAycHggc29saWQgYmxhY2s7XG4gICAgYmFja2dyb3VuZDogI2ZmZmZmZjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYm94LXNoYWRvdzogMC4xNXJlbSAwLjE1cmVtIDAgMCBibGFjaztcbiAgYDtcbiAgICAvLyBDbGljayBoYW5kbGVyIHRvIGFzayBiYWNrZ3JvdW5kIHRvIHJlLWNoZWNrIERyaXZlIGFuZCB1cGRhdGUgc3RhdHVzZXNcbiAgICByZWZldGNoQnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBhc3luYyAoZSkgPT4ge1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAvLyBQcmV2ZW50IG11bHRpcGxlIHNpbXVsdGFuZW91cyByZXF1ZXN0cyBidXQgYWxsb3cgcmUtY2xpY2tpbmcgYWZ0ZXIgY29tcGxldGlvblxuICAgICAgICBpZiAocmVmZXRjaEJ0bi5jbGFzc0xpc3QuY29udGFpbnMoXCJyZWZldGNoaW5nXCIpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgcmVmZXRjaEJ0bi5jbGFzc0xpc3QuYWRkKFwicmVmZXRjaGluZ1wiKTtcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxIVE1MID0gcmVmZXRjaEJ0bi5pbm5lckhUTUw7XG4gICAgICAgIC8vIFNob3cgXCLroZzrlKkg7KSRLi4uXCIgdGV4dFxuICAgICAgICBjb25zdCBjb3VudFNwYW4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImdtdi1tYXgtcHJvZ3Jlc3MtY291bnRcIik7XG4gICAgICAgIGNvbnN0IG9yaWdpbmFsQ291bnRUZXh0ID0gKGNvdW50U3BhbiA9PT0gbnVsbCB8fCBjb3VudFNwYW4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IGNvdW50U3Bhbi50ZXh0Q29udGVudCkgfHwgXCJcIjtcbiAgICAgICAgaWYgKGNvdW50U3Bhbikge1xuICAgICAgICAgICAgY291bnRTcGFuLnRleHRDb250ZW50ID0gXCLroZzrlKkg7KSRLi4uXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gU2hvdyBzcGlubmVyIGFuaW1hdGlvbiBpbiBidXR0b25cbiAgICAgICAgcmVmZXRjaEJ0bi5pbm5lckhUTUwgPSBgXG4gICAgICA8c3ZnIGNsYXNzPVwicmVmZXRjaC1zcGlubmVyXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCIxNFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIj5cbiAgICAgICAgPHBhdGggZD1cIk0yMS41IDJ2NmgtNk0yLjUgMjJ2LTZoNk0yIDExLjVhMTAgMTAgMCAwIDEgMTguOC00LjNNMjIgMTIuNWExMCAxMCAwIDAgMS0xOC44IDQuMlwiLz5cbiAgICAgIDwvc3ZnPlxuICAgIGA7XG4gICAgICAgIC8vIEFkZCBzcGlubmVyIGFuaW1hdGlvbiBzdHlsZVxuICAgICAgICBjb25zdCBzcGlubmVyU3R5bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7XG4gICAgICAgIHNwaW5uZXJTdHlsZS50ZXh0Q29udGVudCA9IGBcbiAgICAgIC5yZWZldGNoLXNwaW5uZXIge1xuICAgICAgICBhbmltYXRpb246IHJlZmV0Y2gtc3BpbiAxcyBsaW5lYXIgaW5maW5pdGU7XG4gICAgICB9XG4gICAgICBAa2V5ZnJhbWVzIHJlZmV0Y2gtc3BpbiB7XG4gICAgICAgIGZyb20geyB0cmFuc2Zvcm06IHJvdGF0ZSgwZGVnKTsgfVxuICAgICAgICB0byB7IHRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7IH1cbiAgICAgIH1cbiAgICBgO1xuICAgICAgICBpZiAoIWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmVmZXRjaC1zcGlubmVyLXN0eWxlXCIpKSB7XG4gICAgICAgICAgICBzcGlubmVyU3R5bGUuaWQgPSBcInJlZmV0Y2gtc3Bpbm5lci1zdHlsZVwiO1xuICAgICAgICAgICAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzcGlubmVyU3R5bGUpO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBcIlJFRkVUQ0hfVVBMT0FEX1NUQVRVU0VTXCIgfSwgKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UgPT09IG51bGwgfHwgcmVzcG9uc2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlc3BvbnNlLnN1Y2Nlc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoKHJlc3BvbnNlID09PSBudWxsIHx8IHJlc3BvbnNlID09PSB2b2lkIDAgPyB2b2lkIDAgOiByZXNwb25zZS5lcnJvcikgfHwgXCJSZWZldGNoIGZhaWxlZFwiKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChfKSB7XG4gICAgICAgICAgICAvLyBLZWVwIHNpbGVudCBpbiBjb250ZW50IFVJLCByZWx5IG9uIHByb2dyZXNzIHVwZGF0aW5nIHdoZW4gcG9zc2libGVcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIGF3YWl0IHVwZGF0ZVByb2dyZXNzVG9hc3QoKTtcbiAgICAgICAgICAgIHJlZmV0Y2hCdG4uaW5uZXJIVE1MID0gb3JpZ2luYWxIVE1MO1xuICAgICAgICAgICAgcmVmZXRjaEJ0bi5jbGFzc0xpc3QucmVtb3ZlKFwicmVmZXRjaGluZ1wiKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIC8vIENvbXBvc2UgdG9hc3QgY29udGVudCBjb250YWluZXIgc28gbnVtYmVycyBhbmQgYnV0dG9uIGFsaWduXG4gICAgY29uc3Qgd3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgd3JhcHBlci5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gICAgd3JhcHBlci5zdHlsZS5hbGlnbkl0ZW1zID0gXCJjZW50ZXJcIjtcbiAgICB3cmFwcGVyLnN0eWxlLmp1c3RpZnlDb250ZW50ID0gXCJzcGFjZS1iZXR3ZWVuXCI7XG4gICAgd3JhcHBlci5zdHlsZS5nYXAgPSBcIjhweFwiO1xuICAgIHdyYXBwZXIuc3R5bGUud2lkdGggPSBcIjEwMCVcIjtcbiAgICBjb25zdCBjb3VudFNwYW4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICBjb3VudFNwYW4uaWQgPSBcImdtdi1tYXgtcHJvZ3Jlc3MtY291bnRcIjtcbiAgICB3cmFwcGVyLmFwcGVuZENoaWxkKGNvdW50U3Bhbik7XG4gICAgd3JhcHBlci5hcHBlbmRDaGlsZChyZWZldGNoQnRuKTtcbiAgICB0b2FzdC5hcHBlbmRDaGlsZCh3cmFwcGVyKTtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRvYXN0KTtcbiAgICBhd2FpdCB1cGRhdGVQcm9ncmVzc1RvYXN0KCk7XG4gICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIFByb2dyZXNzIHRvYXN0IGluamVjdGVkXCIpO1xufVxuLyoqXG4gKiBDb21wdXRlIGFuZCByZW5kZXIgdXBsb2FkZWQvdG90YWwgY2FtcGFpZ25zIGluIHRoZSBwcm9ncmVzcyB0b2FzdFxuICovXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVQcm9ncmVzc1RvYXN0KCkge1xuICAgIGNvbnN0IHRvYXN0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnbXYtbWF4LXByb2dyZXNzLXRvYXN0XCIpO1xuICAgIGlmICghdG9hc3QpXG4gICAgICAgIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICAgICAgXCJnbXZfbWF4X2NhbXBhaWduX2RhdGFcIixcbiAgICAgICAgICAgIFwiZ212X21heF91cGxvYWRfc3VjY2Vzc19zdGF0dXNcIixcbiAgICAgICAgXSk7XG4gICAgICAgIGNvbnN0IGNhbXBhaWducyA9IHJlc3VsdC5nbXZfbWF4X2NhbXBhaWduX2RhdGEgfHwgW107XG4gICAgICAgIGNvbnN0IHN1Y2Nlc3NTdGF0dXNlcyA9IHJlc3VsdC5nbXZfbWF4X3VwbG9hZF9zdWNjZXNzX3N0YXR1cyB8fCB7fTtcbiAgICAgICAgY29uc3QgdG90YWwgPSBjYW1wYWlnbnMubGVuZ3RoO1xuICAgICAgICBjb25zdCB1cGxvYWRlZCA9IHRvdGFsID09PSAwID8gMCA6IGNhbXBhaWducy5maWx0ZXIoKGMpID0+IHsgdmFyIF9hOyByZXR1cm4gKChfYSA9IHN1Y2Nlc3NTdGF0dXNlc1tjLm5hbWVdKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2Euc3RhdHVzKSA9PT0gXCJzdWNjZXNzXCI7IH0pLmxlbmd0aDtcbiAgICAgICAgaWYgKHRvdGFsID4gMCkge1xuICAgICAgICAgICAgLy8gU2hvdyBwcm9ncmVzcyBudW1iZXJzIGJ5IGRlZmF1bHQsIHdpbGwgYmUgaGlkZGVuIG9uIGhvdmVyXG4gICAgICAgICAgICBjb25zdCBjb3VudFNwYW4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImdtdi1tYXgtcHJvZ3Jlc3MtY291bnRcIik7XG4gICAgICAgICAgICBpZiAoY291bnRTcGFuKSB7XG4gICAgICAgICAgICAgICAgY291bnRTcGFuLnRleHRDb250ZW50ID0gYCR7dXBsb2FkZWR9LyR7dG90YWx9YDtcbiAgICAgICAgICAgICAgICBjb3VudFNwYW4uc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0b2FzdC50ZXh0Q29udGVudCA9IGAgJHt1cGxvYWRlZH0vJHt0b3RhbH1gO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdG9hc3Quc3R5bGUuZGlzcGxheSA9IFwiZmxleFwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdG9hc3Quc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIC8vIE9uIGVycm9yLCBoaWRlIHRvIGF2b2lkIHN0YWxlIGRpc3BsYXlcbiAgICAgICAgdG9hc3Quc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgIH1cbn1cbi8qKlxuICogQ2hlY2sgY2FtcGFpZ25zIGFuZCBwYXVzZSB3b3JrZmxvdyBpZiBub25lIHBlbmRpbmdcbiAqL1xuYXN5bmMgZnVuY3Rpb24gY2hlY2tBbmRQYXVzZUlmTm9QZW5kaW5nQ2FtcGFpZ25zKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbXG4gICAgICAgICAgICBcImdtdl9tYXhfY2FtcGFpZ25fZGF0YVwiLFxuICAgICAgICAgICAgXCJnbXZfbWF4X3VwbG9hZF9zdWNjZXNzX3N0YXR1c1wiLFxuICAgICAgICBdKTtcbiAgICAgICAgY29uc3QgY2FtcGFpZ25zID0gcmVzdWx0Lmdtdl9tYXhfY2FtcGFpZ25fZGF0YSB8fCBbXTtcbiAgICAgICAgY29uc3Qgc3VjY2Vzc1N0YXR1c2VzID0gcmVzdWx0Lmdtdl9tYXhfdXBsb2FkX3N1Y2Nlc3Nfc3RhdHVzIHx8IHt9O1xuICAgICAgICBjb25zdCB0b3RhbCA9IGNhbXBhaWducy5sZW5ndGg7XG4gICAgICAgIGNvbnN0IHVwbG9hZGVkID0gdG90YWwgPT09IDAgPyAwIDogY2FtcGFpZ25zLmZpbHRlcigoYykgPT4geyB2YXIgX2E7IHJldHVybiAoKF9hID0gc3VjY2Vzc1N0YXR1c2VzW2MubmFtZV0pID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5zdGF0dXMpID09PSBcInN1Y2Nlc3NcIjsgfSkubGVuZ3RoO1xuICAgICAgICBjb25zdCBoYXNQZW5kaW5nID0gdG90YWwgPiAwICYmIHVwbG9hZGVkIDwgdG90YWw7XG4gICAgICAgIGlmICghaGFzUGVuZGluZykge1xuICAgICAgICAgICAgLy8gTm8gY2FtcGFpZ25zIG9yIGFsbCBjb21wbGV0ZWQgLT4gcGF1c2VcbiAgICAgICAgICAgIGlzQXV0b05hdmlnYXRpb25QYXVzZWQgPSB0cnVlO1xuICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1dPUktGTE9XX1BBVVNFRF9LRVldOiB0cnVlIH0pO1xuICAgICAgICAgICAgdXBkYXRlQ29udHJvbEJ1dHRvbnMoKTtcbiAgICAgICAgICAgIHVwZGF0ZVVwbG9hZFN0YXR1c1RvYXN0KFwiaWRsZVwiKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBObyBwZW5kaW5nIGNhbXBhaWducy4gV29ya2Zsb3cgcGF1c2VkLlwiKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICAvLyBJZ25vcmUgZXJyb3JzLCBkbyBub3QgZm9yY2UgcmVzdW1lXG4gICAgfVxufVxuLyoqXG4gKiBVcGRhdGUgY29udHJvbCBidXR0b25zIHZpc2liaWxpdHkgYW5kIHN0YXRlXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUNvbnRyb2xCdXR0b25zKCkge1xuICAgIGNvbnN0IHN0b3BCdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImdtdi1tYXgtc3RvcC1idG5cIik7XG4gICAgY29uc3QgcmVzdW1lQnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnbXYtbWF4LXJlc3VtZS1idG5cIik7XG4gICAgaWYgKHN0b3BCdXR0b24gJiYgcmVzdW1lQnV0dG9uKSB7XG4gICAgICAgIC8vIENoZWNrIGlmIGNhbXBhaWducyBhcmUgY29uZmlndXJlZCAob25seSBuZWVkIGNhbXBhaWduIGRhdGEgbm93KVxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1xuICAgICAgICAgICAgXCJnbXZfbWF4X2NhbXBhaWduX2RhdGFcIixcbiAgICAgICAgICAgIFwiZ212X21heF91cGxvYWRfc3VjY2Vzc19zdGF0dXNcIixcbiAgICAgICAgXSk7XG4gICAgICAgIGNvbnN0IGNhbXBhaWducyA9IHJlc3VsdC5nbXZfbWF4X2NhbXBhaWduX2RhdGEgfHwgW107XG4gICAgICAgIGNvbnN0IHN1Y2Nlc3NTdGF0dXNlcyA9IHJlc3VsdC5nbXZfbWF4X3VwbG9hZF9zdWNjZXNzX3N0YXR1cyB8fCB7fTtcbiAgICAgICAgY29uc3QgaXNDb25maWd1cmVkID0gY2FtcGFpZ25zLmxlbmd0aCA+IDA7XG4gICAgICAgIC8vIENoZWNrIGlmIHByb2dyZXNzIGlzIGZ1bGwgKGFsbCBjYW1wYWlnbnMgdXBsb2FkZWQpXG4gICAgICAgIGNvbnN0IHRvdGFsID0gY2FtcGFpZ25zLmxlbmd0aDtcbiAgICAgICAgY29uc3QgdXBsb2FkZWQgPSB0b3RhbCA9PT0gMCA/IDAgOiBjYW1wYWlnbnMuZmlsdGVyKChjKSA9PiB7IHZhciBfYTsgcmV0dXJuICgoX2EgPSBzdWNjZXNzU3RhdHVzZXNbYy5uYW1lXSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnN0YXR1cykgPT09IFwic3VjY2Vzc1wiOyB9KS5sZW5ndGg7XG4gICAgICAgIGNvbnN0IGlzUHJvZ3Jlc3NGdWxsID0gdG90YWwgPiAwICYmIHVwbG9hZGVkID09PSB0b3RhbDtcbiAgICAgICAgLy8gRGlzYWJsZSBidXR0b25zIGlmIG5vdCBjb25maWd1cmVkIE9SIGlmIHByb2dyZXNzIGlzIGZ1bGxcbiAgICAgICAgY29uc3Qgc2hvdWxkRGlzYWJsZSA9ICFpc0NvbmZpZ3VyZWQgfHwgaXNQcm9ncmVzc0Z1bGw7XG4gICAgICAgIHN0b3BCdXR0b24uZGlzYWJsZWQgPSBzaG91bGREaXNhYmxlO1xuICAgICAgICByZXN1bWVCdXR0b24uZGlzYWJsZWQgPSBzaG91bGREaXNhYmxlO1xuICAgICAgICAvLyBVcGRhdGUgb3BhY2l0eSB0byBzaG93IGRpc2FibGVkIHN0YXRlXG4gICAgICAgIGlmIChzaG91bGREaXNhYmxlKSB7XG4gICAgICAgICAgICBzdG9wQnV0dG9uLnN0eWxlLm9wYWNpdHkgPSBcIjAuNVwiO1xuICAgICAgICAgICAgc3RvcEJ1dHRvbi5zdHlsZS5jdXJzb3IgPSBcIm5vdC1hbGxvd2VkXCI7XG4gICAgICAgICAgICByZXN1bWVCdXR0b24uc3R5bGUub3BhY2l0eSA9IFwiMC41XCI7XG4gICAgICAgICAgICByZXN1bWVCdXR0b24uc3R5bGUuY3Vyc29yID0gXCJub3QtYWxsb3dlZFwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgc3RvcEJ1dHRvbi5zdHlsZS5vcGFjaXR5ID0gXCIxXCI7XG4gICAgICAgICAgICBzdG9wQnV0dG9uLnN0eWxlLmN1cnNvciA9IFwicG9pbnRlclwiO1xuICAgICAgICAgICAgcmVzdW1lQnV0dG9uLnN0eWxlLm9wYWNpdHkgPSBcIjFcIjtcbiAgICAgICAgICAgIHJlc3VtZUJ1dHRvbi5zdHlsZS5jdXJzb3IgPSBcInBvaW50ZXJcIjtcbiAgICAgICAgfVxuICAgICAgICAvLyBVcGRhdGUgdmlzaWJpbGl0eSBiYXNlZCBvbiBwYXVzZWQgc3RhdGVcbiAgICAgICAgaWYgKGlzQXV0b05hdmlnYXRpb25QYXVzZWQpIHtcbiAgICAgICAgICAgIHN0b3BCdXR0b24uc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgICAgcmVzdW1lQnV0dG9uLnN0eWxlLmRpc3BsYXkgPSBcImZsZXhcIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHN0b3BCdXR0b24uc3R5bGUuZGlzcGxheSA9IFwiZmxleFwiO1xuICAgICAgICAgICAgcmVzdW1lQnV0dG9uLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgfVxuICAgIH1cbn1cbi8qKlxuICogVXBkYXRlIG5hdmlnYXRpb24gYnV0dG9ucyBzdGF0ZSBiYXNlZCBvbiBjdXJyZW50IGNvbmZpZ3VyYXRpb25cbiAqL1xuYXN5bmMgZnVuY3Rpb24gdXBkYXRlTmF2aWdhdGlvbkJ1dHRvbnMoKSB7XG4gICAgY29uc3QgcHJldkJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZ212LW1heC1wcmV2LWNhbXBhaWduLWJ0blwiKTtcbiAgICBjb25zdCBuZXh0QnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnbXYtbWF4LW5leHQtY2FtcGFpZ24tYnRuXCIpO1xuICAgIGlmIChwcmV2QnV0dG9uICYmIG5leHRCdXR0b24pIHtcbiAgICAgICAgLy8gQ2hlY2sgaWYgY2FtcGFpZ25zIGFyZSBjb25maWd1cmVkIChvbmx5IG5lZWQgY2FtcGFpZ24gZGF0YSBub3cpXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbXCJnbXZfbWF4X2NhbXBhaWduX2RhdGFcIl0pO1xuICAgICAgICBjb25zdCBjYW1wYWlnbnMgPSByZXN1bHQuZ212X21heF9jYW1wYWlnbl9kYXRhIHx8IFtdO1xuICAgICAgICBjb25zdCBpc0NvbmZpZ3VyZWQgPSBjYW1wYWlnbnMubGVuZ3RoID4gMDtcbiAgICAgICAgLy8gRGlzYWJsZSBidXR0b25zIGlmIG5vdCBjb25maWd1cmVkXG4gICAgICAgIGNvbnN0IHNob3VsZERpc2FibGUgPSAhaXNDb25maWd1cmVkO1xuICAgICAgICAvLyBVcGRhdGUgYnV0dG9uIHN0YXRlc1xuICAgICAgICBwcmV2QnV0dG9uLmRpc2FibGVkID0gc2hvdWxkRGlzYWJsZTtcbiAgICAgICAgcHJldkJ1dHRvbi5zdHlsZS5vcGFjaXR5ID0gc2hvdWxkRGlzYWJsZSA/IFwiMC41XCIgOiBcIjFcIjtcbiAgICAgICAgcHJldkJ1dHRvbi5zdHlsZS5jdXJzb3IgPSBzaG91bGREaXNhYmxlID8gXCJub3QtYWxsb3dlZFwiIDogXCJwb2ludGVyXCI7XG4gICAgICAgIG5leHRCdXR0b24uZGlzYWJsZWQgPSBzaG91bGREaXNhYmxlO1xuICAgICAgICBuZXh0QnV0dG9uLnN0eWxlLm9wYWNpdHkgPSBzaG91bGREaXNhYmxlID8gXCIwLjVcIiA6IFwiMVwiO1xuICAgICAgICBuZXh0QnV0dG9uLnN0eWxlLmN1cnNvciA9IHNob3VsZERpc2FibGUgPyBcIm5vdC1hbGxvd2VkXCIgOiBcInBvaW50ZXJcIjtcbiAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIE5hdmlnYXRpb24gYnV0dG9ucyBzdGF0ZSB1cGRhdGVkOlwiLCB7IGlzQ29uZmlndXJlZCB9KTtcbiAgICB9XG59XG4vKipcbiAqIEluamVjdCBzdG9wIGFuZCByZXN1bWUgY29udHJvbCBidXR0b25zXG4gKiBBbHdheXMgdmlzaWJsZSwgYnV0IGRpc2FibGVkIHdoZW4gY2FtcGFpZ25zIGFyZSBub3QgY29uZmlndXJlZFxuICovXG5hc3luYyBmdW5jdGlvbiBpbmplY3RDb250cm9sQnV0dG9ucygpIHtcbiAgICAvLyBDaGVjayBpZiBidXR0b25zIGFscmVhZHkgZXhpc3RcbiAgICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnbXYtbWF4LXN0b3AtYnRuXCIpIHx8IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZ212LW1heC1yZXN1bWUtYnRuXCIpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gQ3JlYXRlIFN0b3AgYnV0dG9uXG4gICAgY29uc3Qgc3RvcEJ1dHRvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIik7XG4gICAgc3RvcEJ1dHRvbi5pZCA9IFwiZ212LW1heC1zdG9wLWJ0blwiO1xuICAgIHN0b3BCdXR0b24uaW5uZXJIVE1MID0gYFxuICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPVwiMTZcIiBoZWlnaHQ9XCIxNlwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIj5cbiAgICAgIDxyZWN0IHg9XCI2XCIgeT1cIjZcIiB3aWR0aD1cIjEyXCIgaGVpZ2h0PVwiMTJcIj48L3JlY3Q+XG4gICAgPC9zdmc+XG4gICAgPHNwYW4+7J287Iuc7KCV7KeAPC9zcGFuPlxuICBgO1xuICAgIHN0b3BCdXR0b24uc3R5bGUuY3NzVGV4dCA9IGBcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgYm90dG9tOiA4NXB4O1xuICAgIHJpZ2h0OiAzMnB4O1xuICAgIHdpZHRoOiAxNTBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgei1pbmRleDogMTAwMDA7XG4gICAgYmFja2dyb3VuZDogcmVkO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbiAgICBib3gtc2hhZG93OiAwLjJyZW0gMC4ycmVtIDAgMCBibGFjaztcbiAgICBwYWRkaW5nOiAxMnB4IDE4cHg7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGdhcDogNnB4O1xuICAgIHRyYW5zaXRpb246IGFsbCAwLjNzIGN1YmljLWJlemllcigwLjQsIDAsIDAuMiwgMSk7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsICdTZWdvZSBVSScsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgYDtcbiAgICAvLyBDcmVhdGUgUmVzdW1lIGJ1dHRvblxuICAgIGNvbnN0IHJlc3VtZUJ1dHRvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIik7XG4gICAgcmVzdW1lQnV0dG9uLmlkID0gXCJnbXYtbWF4LXJlc3VtZS1idG5cIjtcbiAgICByZXN1bWVCdXR0b24uaW5uZXJIVE1MID0gYFxuICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPVwiMTZcIiBoZWlnaHQ9XCIxNlwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIj5cbiAgICAgIDxwb2x5Z29uIHBvaW50cz1cIjUgMyAxOSAxMiA1IDIxIDUgM1wiPjwvcG9seWdvbj5cbiAgICA8L3N2Zz5cbiAgICA8c3Bhbj7snqzqsJw8L3NwYW4+XG4gIGA7XG4gICAgcmVzdW1lQnV0dG9uLnN0eWxlLmNzc1RleHQgPSBgXG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIGJvdHRvbTogODVweDtcbiAgICByaWdodDogMzJweDtcbiAgICB3aWR0aDogMTUwcHg7XG4gICAgaGVpZ2h0OiA0MHB4O1xuICAgIHotaW5kZXg6IDEwMDAwO1xuICAgIGJhY2tncm91bmQ6ICMyMmM1NWU7XG4gICAgYm9yZGVyOiAycHggc29saWQgYmxhY2s7XG4gICAgYm94LXNoYWRvdzogMC4ycmVtIDAuMnJlbSAwIDAgYmxhY2s7XG4gICAgcGFkZGluZzogMTJweCAxOHB4O1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBnYXA6IDZweDtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBjdWJpYy1iZXppZXIoMC40LCAwLCAwLjIsIDEpO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgY29sb3I6IHdoaXRlO1xuICBgO1xuICAgIC8vIEFkZCBob3ZlciBlZmZlY3RzIGZvciBTdG9wIGJ1dHRvblxuICAgIHN0b3BCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZW50ZXJcIiwgKCkgPT4ge1xuICAgICAgICBzdG9wQnV0dG9uLnN0eWxlLmJveFNoYWRvdyA9IFwibm9uZVwiO1xuICAgIH0pO1xuICAgIHN0b3BCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlbGVhdmVcIiwgKCkgPT4ge1xuICAgICAgICBzdG9wQnV0dG9uLnN0eWxlLmJveFNoYWRvdyA9IFwiMC4ycmVtIDAuMnJlbSAwIDAgYmxhY2tcIjtcbiAgICB9KTtcbiAgICAvLyBBZGQgaG92ZXIgZWZmZWN0cyBmb3IgUmVzdW1lIGJ1dHRvblxuICAgIHJlc3VtZUJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKFwibW91c2VlbnRlclwiLCAoKSA9PiB7XG4gICAgICAgIHJlc3VtZUJ1dHRvbi5zdHlsZS5ib3hTaGFkb3cgPSBcIm5vbmVcIjtcbiAgICB9KTtcbiAgICByZXN1bWVCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlbGVhdmVcIiwgKCkgPT4ge1xuICAgICAgICByZXN1bWVCdXR0b24uc3R5bGUuYm94U2hhZG93ID0gXCIwLjJyZW0gMC4ycmVtIDAgMCBibGFja1wiO1xuICAgIH0pO1xuICAgIC8vIFN0b3AgYnV0dG9uIGNsaWNrIGhhbmRsZXJcbiAgICBzdG9wQnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmIChzdG9wQnV0dG9uLmRpc2FibGVkKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBpc0F1dG9OYXZpZ2F0aW9uUGF1c2VkID0gdHJ1ZTtcbiAgICAgICAgLy8gUGVyc2lzdCB3b3JrZmxvdyBwYXVzZWQgc3RhdGUgdG8gbG9jYWxTdG9yYWdlXG4gICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtXT1JLRkxPV19QQVVTRURfS0VZXTogdHJ1ZSB9KTtcbiAgICAgICAgYXdhaXQgdXBkYXRlQ29udHJvbEJ1dHRvbnMoKTtcbiAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIEF1dG8tbmF2aWdhdGlvbiBwYXVzZWRcIik7XG4gICAgICAgIHVwZGF0ZVVwbG9hZFN0YXR1c1RvYXN0KFwiaWRsZVwiKTtcbiAgICB9KTtcbiAgICAvLyBSZXN1bWUgYnV0dG9uIGNsaWNrIGhhbmRsZXJcbiAgICByZXN1bWVCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKHJlc3VtZUJ1dHRvbi5kaXNhYmxlZClcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIEF1dG8tbmF2aWdhdGlvbiByZXN1bWVkLCBuYXZpZ2F0aW5nIHRvIGZpcnN0IGNhbXBhaWduXCIpO1xuICAgICAgICBpc0F1dG9OYXZpZ2F0aW9uUGF1c2VkID0gZmFsc2U7XG4gICAgICAgIC8vIFBlcnNpc3Qgd29ya2Zsb3cgcmVzdW1lZCBzdGF0ZSB0byBsb2NhbFN0b3JhZ2VcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1dPUktGTE9XX1BBVVNFRF9LRVldOiBmYWxzZSB9KTtcbiAgICAgICAgLy8gUmVzZXQgdGhlIGNsaWNrIGZsYWcgdG8gYWxsb3cgY2xpY2tpbmcgYWdhaW5cbiAgICAgICAgaGFzQ2xpY2tlZEV4cG9ydEJ1dHRvbiA9IGZhbHNlO1xuICAgICAgICAvLyBOYXZpZ2F0ZSB0byB0aGUgZmlyc3QgdW5jb21wbGV0ZWQgY2FtcGFpZ25cbiAgICAgICAgYXdhaXQgZ29Ub0ZpcnN0Q2FtcGFpZ24oKTtcbiAgICAgICAgLy8gVXBkYXRlIGNvbnRyb2wgYnV0dG9ucyB0byBzaG93IHN0b3AgYnV0dG9uXG4gICAgICAgIHVwZGF0ZUNvbnRyb2xCdXR0b25zKCk7XG4gICAgICAgIC8vIEVuYWJsZSBuYXZpZ2F0aW9uIGJ1dHRvbnNcbiAgICAgICAgdXBkYXRlTmF2aWdhdGlvbkJ1dHRvbnMoKTtcbiAgICB9KTtcbiAgICAvLyBJbmplY3QgYnV0dG9uc1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoc3RvcEJ1dHRvbik7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChyZXN1bWVCdXR0b24pO1xuICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBDb250cm9sIGJ1dHRvbnMgaW5qZWN0ZWRcIik7XG4gICAgLy8gU2V0IGluaXRpYWwgYnV0dG9uIHZpc2liaWxpdHkgYmFzZWQgb24gcGF1c2VkIHN0YXRlXG4gICAgdXBkYXRlQ29udHJvbEJ1dHRvbnMoKTtcbn1cbi8qKlxuICogSW5qZWN0IGZsb2F0aW5nIG5hdmlnYXRpb24gYnV0dG9ucyAoUHJldi9OZXh0KSBpbnRvIHRoZSBwYWdlXG4gKiBBbHdheXMgdmlzaWJsZSwgYnV0IGRpc2FibGVkIHdoZW4gY2FtcGFpZ25zIGFyZSBub3QgY29uZmlndXJlZFxuICovXG5hc3luYyBmdW5jdGlvbiBpbmplY3ROYXZpZ2F0aW9uQnV0dG9ucygpIHtcbiAgICAvLyBDaGVjayBpZiBidXR0b25zIGFscmVhZHkgZXhpc3RcbiAgICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnbXYtbWF4LXByZXYtY2FtcGFpZ24tYnRuXCIpIHx8IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZ212LW1heC1uZXh0LWNhbXBhaWduLWJ0blwiKSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIENoZWNrIGlmIGNhbXBhaWducyBhcmUgY29uZmlndXJlZCAob25seSBuZWVkIGNhbXBhaWduIGRhdGEgbm93KVxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbXCJnbXZfbWF4X2NhbXBhaWduX2RhdGFcIl0pO1xuICAgIGNvbnN0IGNhbXBhaWducyA9IHJlc3VsdC5nbXZfbWF4X2NhbXBhaWduX2RhdGEgfHwgW107XG4gICAgY29uc3QgaXNDb25maWd1cmVkID0gY2FtcGFpZ25zLmxlbmd0aCA+IDA7XG4gICAgLy8gQ3JlYXRlIGNvbnRhaW5lciBmb3IgYnV0dG9uc1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgY29udGFpbmVyLmlkID0gXCJnbXYtbWF4LW5hdmlnYXRpb24tY29udGFpbmVyXCI7XG4gICAgY29udGFpbmVyLnN0eWxlLmNzc1RleHQgPSBgXG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIGJvdHRvbTogMzJweDtcbiAgICByaWdodDogMzJweDtcbiAgICB6LWluZGV4OiAxMDAwMDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGdhcDogNHB4O1xuICAgIHdpZHRoOiAxNTBweDtcbiAgYDtcbiAgICAvLyBDcmVhdGUgUHJldiBidXR0b25cbiAgICBjb25zdCBwcmV2QnV0dG9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcbiAgICBwcmV2QnV0dG9uLmlkID0gXCJnbXYtbWF4LXByZXYtY2FtcGFpZ24tYnRuXCI7XG4gICAgcHJldkJ1dHRvbi5pbm5lckhUTUwgPSBgXG4gICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiPlxuICAgICAgPHBvbHlsaW5lIHBvaW50cz1cIjE1IDE4IDkgMTIgMTUgNlwiPjwvcG9seWxpbmU+XG4gICAgPC9zdmc+XG4gIGA7XG4gICAgLy8gU2V0IGluaXRpYWwgZGlzYWJsZWQgc3RhdGVcbiAgICBwcmV2QnV0dG9uLmRpc2FibGVkID0gIWlzQ29uZmlndXJlZDtcbiAgICAvLyBBZGQgc3R5bGVzIGZvciBwcmV2IGJ1dHRvblxuICAgIHByZXZCdXR0b24uc3R5bGUuY3NzVGV4dCA9IGBcbiAgICBmbGV4OiAxO1xuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgIGNvbG9yOiBibGFjaztcbiAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcbiAgICBib3gtc2hhZG93OiAwLjJyZW0gMC4ycmVtIDAgMCBibGFjaztcbiAgICBwYWRkaW5nOiAxMnB4O1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBjdWJpYy1iZXppZXIoMC40LCAwLCAwLjIsIDEpO1xuICAgIGN1cnNvcjogJHtpc0NvbmZpZ3VyZWQgPyBcInBvaW50ZXJcIiA6IFwibm90LWFsbG93ZWRcIn07XG4gICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgJ1NlZ29lIFVJJywgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIG9wYWNpdHk6ICR7aXNDb25maWd1cmVkID8gXCIxXCIgOiBcIjAuNVwifTtcbiAgYDtcbiAgICAvLyBDcmVhdGUgTmV4dCBidXR0b25cbiAgICBjb25zdCBuZXh0QnV0dG9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcbiAgICBuZXh0QnV0dG9uLmlkID0gXCJnbXYtbWF4LW5leHQtY2FtcGFpZ24tYnRuXCI7XG4gICAgbmV4dEJ1dHRvbi5pbm5lckhUTUwgPSBgXG4gICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiPlxuICAgICAgPHBvbHlsaW5lIHBvaW50cz1cIjkgMTggMTUgMTIgOSA2XCI+PC9wb2x5bGluZT5cbiAgICA8L3N2Zz5cbiAgYDtcbiAgICAvLyBTZXQgaW5pdGlhbCBkaXNhYmxlZCBzdGF0ZVxuICAgIG5leHRCdXR0b24uZGlzYWJsZWQgPSAhaXNDb25maWd1cmVkO1xuICAgIC8vIEFkZCBzdHlsZXMgZm9yIG5leHQgYnV0dG9uXG4gICAgbmV4dEJ1dHRvbi5zdHlsZS5jc3NUZXh0ID0gYFxuICAgIGZsZXg6IDE7XG4gICAgYmFja2dyb3VuZDogYmxhY2s7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xuICAgIGJveC1zaGFkb3c6IDAuMnJlbSAwLjJyZW0gMCAwIGJsYWNrO1xuICAgIHBhZGRpbmc6IDEycHg7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIHRyYW5zaXRpb246IGFsbCAwLjNzIGN1YmljLWJlemllcigwLjQsIDAsIDAuMiwgMSk7XG4gICAgY3Vyc29yOiAke2lzQ29uZmlndXJlZCA/IFwicG9pbnRlclwiIDogXCJub3QtYWxsb3dlZFwifTtcbiAgICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgb3BhY2l0eTogJHtpc0NvbmZpZ3VyZWQgPyBcIjFcIiA6IFwiMC41XCJ9O1xuICBgO1xuICAgIC8vIEFkZCBob3ZlciBlZmZlY3RzIGZvciBwcmV2IGJ1dHRvblxuICAgIHByZXZCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZW50ZXJcIiwgKCkgPT4ge1xuICAgICAgICBpZiAoIXByZXZCdXR0b24uZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHByZXZCdXR0b24uc3R5bGUuYm94U2hhZG93ID0gXCJub25lXCI7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBwcmV2QnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZWxlYXZlXCIsICgpID0+IHtcbiAgICAgICAgaWYgKCFwcmV2QnV0dG9uLmRpc2FibGVkKSB7XG4gICAgICAgICAgICBwcmV2QnV0dG9uLnN0eWxlLmJveFNoYWRvdyA9IFwiMC4ycmVtIDAuMnJlbSAwIDAgYmxhY2tcIjtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIC8vIEFkZCBob3ZlciBlZmZlY3RzIGZvciBuZXh0IGJ1dHRvblxuICAgIG5leHRCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZW50ZXJcIiwgKCkgPT4ge1xuICAgICAgICBpZiAoIW5leHRCdXR0b24uZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIG5leHRCdXR0b24uc3R5bGUuYm94U2hhZG93ID0gXCJub25lXCI7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBuZXh0QnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZWxlYXZlXCIsICgpID0+IHtcbiAgICAgICAgaWYgKCFuZXh0QnV0dG9uLmRpc2FibGVkKSB7XG4gICAgICAgICAgICBuZXh0QnV0dG9uLnN0eWxlLmJveFNoYWRvdyA9IFwiMC4ycmVtIDAuMnJlbSAwIDAgYmxhY2tcIjtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIC8vIEFkZCBjbGljayBoYW5kbGVyIGZvciBwcmV2IGJ1dHRvblxuICAgIHByZXZCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGFzeW5jICgpID0+IHtcbiAgICAgICAgaWYgKHByZXZCdXR0b24uZGlzYWJsZWQpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGNvbnN0IG9yaWdpbmFsRGlzYWJsZWQgPSBwcmV2QnV0dG9uLmRpc2FibGVkO1xuICAgICAgICBwcmV2QnV0dG9uLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgICAgcHJldkJ1dHRvbi5zdHlsZS5vcGFjaXR5ID0gXCIwLjZcIjtcbiAgICAgICAgcHJldkJ1dHRvbi5zdHlsZS5jdXJzb3IgPSBcIm5vdC1hbGxvd2VkXCI7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBnb1RvUHJldkNhbXBhaWduKCk7XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICBwcmV2QnV0dG9uLmRpc2FibGVkID0gb3JpZ2luYWxEaXNhYmxlZDtcbiAgICAgICAgICAgIHByZXZCdXR0b24uc3R5bGUub3BhY2l0eSA9IGlzQ29uZmlndXJlZCA/IFwiMVwiIDogXCIwLjVcIjtcbiAgICAgICAgICAgIHByZXZCdXR0b24uc3R5bGUuY3Vyc29yID0gaXNDb25maWd1cmVkID8gXCJwb2ludGVyXCIgOiBcIm5vdC1hbGxvd2VkXCI7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICAvLyBBZGQgY2xpY2sgaGFuZGxlciBmb3IgbmV4dCBidXR0b25cbiAgICBuZXh0QnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmIChuZXh0QnV0dG9uLmRpc2FibGVkKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjb25zdCBvcmlnaW5hbERpc2FibGVkID0gbmV4dEJ1dHRvbi5kaXNhYmxlZDtcbiAgICAgICAgbmV4dEJ1dHRvbi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICAgIG5leHRCdXR0b24uc3R5bGUub3BhY2l0eSA9IFwiMC42XCI7XG4gICAgICAgIG5leHRCdXR0b24uc3R5bGUuY3Vyc29yID0gXCJub3QtYWxsb3dlZFwiO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgZ29Ub05leHRDYW1wYWlnbigpO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgbmV4dEJ1dHRvbi5kaXNhYmxlZCA9IG9yaWdpbmFsRGlzYWJsZWQ7XG4gICAgICAgICAgICBuZXh0QnV0dG9uLnN0eWxlLm9wYWNpdHkgPSBpc0NvbmZpZ3VyZWQgPyBcIjFcIiA6IFwiMC41XCI7XG4gICAgICAgICAgICBuZXh0QnV0dG9uLnN0eWxlLmN1cnNvciA9IGlzQ29uZmlndXJlZCA/IFwicG9pbnRlclwiIDogXCJub3QtYWxsb3dlZFwiO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgLy8gQXBwZW5kIGJ1dHRvbnMgdG8gY29udGFpbmVyXG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKHByZXZCdXR0b24pO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChuZXh0QnV0dG9uKTtcbiAgICAvLyBJbmplY3QgY29udGFpbmVyIGludG8gcGFnZVxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoY29udGFpbmVyKTtcbiAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gTmF2aWdhdGlvbiBidXR0b25zIGluamVjdGVkXCIpO1xufVxuLyoqXG4gKiBMaXN0ZW4gZm9yIHVwbG9hZCBzdGF0dXMgbWVzc2FnZXMgZnJvbSBiYWNrZ3JvdW5kIHNjcmlwdFxuICovXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UpID0+IHtcbiAgICBpZiAobWVzc2FnZS50eXBlID09PSBcIlVQTE9BRF9TVEFUVVNcIikge1xuICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gUmVjZWl2ZWQgdXBsb2FkIHN0YXR1czpcIiwgbWVzc2FnZSk7XG4gICAgICAgIC8vIEdldCBjYW1wYWlnbiBpbmZvIGZyb20gY3VycmVudCBVUkwgdG8gY2hlY2sgaWYgdGhpcyBzdGF0dXMgdXBkYXRlIGlzIGZvciB0aGUgY3VycmVudCBjYW1wYWlnblxuICAgICAgICBjb25zdCBjYW1wYWlnbklkID0gZ2V0Q2FtcGFpZ25JZEZyb21VcmwoKTtcbiAgICAgICAgaWYgKCFjYW1wYWlnbklkKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBnZXRDYW1wYWlnbk5hbWUoY2FtcGFpZ25JZCkudGhlbigoY2FtcGFpZ25OYW1lKSA9PiB7XG4gICAgICAgICAgICAvLyBPbmx5IHNob3cgc3RhdHVzIGlmIGl0J3MgZm9yIHRoZSBjdXJyZW50IGNhbXBhaWduXG4gICAgICAgICAgICBpZiAoY2FtcGFpZ25OYW1lID09PSBtZXNzYWdlLmNhbXBhaWduTmFtZSkge1xuICAgICAgICAgICAgICAgIHN3aXRjaCAobWVzc2FnZS5zdGF0dXMpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcInN0YXJ0ZWRcIjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZVVwbG9hZFN0YXR1c1RvYXN0KFwidXBsb2FkaW5nXCIsIFwi7JeF66Gc65OcIOykkS4uLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZVByb2dyZXNzVG9hc3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIFwic3VjY2Vzc1wiOlxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlVXBsb2FkU3RhdHVzVG9hc3QoXCJzdWNjZXNzXCIsIFwi7JeF66Gc65OcIOyZhOujjFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFBlcnNpc3Qgc3VjY2VzcyB0byBjaHJvbWUuc3RvcmFnZSBzbyBwcm9ncmVzcyBzdGF5cyBhY2N1cmF0ZSBldmVuIGlmIHBvcHVwIGlzIGNsb3NlZFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFtcImdtdl9tYXhfdXBsb2FkX3N1Y2Nlc3Nfc3RhdHVzXCJdLCAocmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3VjY2Vzc1N0YXR1c2VzID0gcmVzdWx0Lmdtdl9tYXhfdXBsb2FkX3N1Y2Nlc3Nfc3RhdHVzIHx8IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3NTdGF0dXNlc1ttZXNzYWdlLmNhbXBhaWduTmFtZV0gPSB7IHN0YXR1czogXCJzdWNjZXNzXCIgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBnbXZfbWF4X3VwbG9hZF9zdWNjZXNzX3N0YXR1czogc3VjY2Vzc1N0YXR1c2VzIH0sICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlUHJvZ3Jlc3NUb2FzdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBBdXRvLWNsaWNrIFwiTmV4dCBDYW1wYWlnblwiIGJ1dHRvbiBhZnRlciBzdWNjZXNzZnVsIHVwbG9hZCAob25seSBpZiBub3QgcGF1c2VkKVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc0F1dG9OYXZpZ2F0aW9uUGF1c2VkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYFtHTVYgTWF4IE5hdmlnYXRvcl0gVXBsb2FkIHN1Y2Nlc3NmdWwsIGF1dG8tY2xpY2tpbmcgbmV4dCBjYW1wYWlnbiBidXR0b24gaW4gJHtBVVRPX05BVklHQVRJT05fREVMQVkgLyAxMDAwfSBzZWNvbmRzLi4uYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENoZWNrIGFnYWluIGlmIHN0aWxsIG5vdCBwYXVzZWQgKHVzZXIgbWlnaHQgaGF2ZSBjbGlja2VkIHN0b3AgZHVyaW5nIGRlbGF5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzQXV0b05hdmlnYXRpb25QYXVzZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5leHRCdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImdtdi1tYXgtbmV4dC1jYW1wYWlnbi1idG5cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobmV4dEJ1dHRvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBBdXRvLWNsaWNraW5nIG5leHQgY2FtcGFpZ24gYnV0dG9uXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5leHRCdXR0b24uY2xpY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihcIltHTVYgTWF4IE5hdmlnYXRvcl0gTmV4dCBjYW1wYWlnbiBidXR0b24gbm90IGZvdW5kXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIEF1dG8tbmF2aWdhdGlvbiBpcyBwYXVzZWQsIHNraXBwaW5nIGF1dG8tY2xpY2tcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCBBVVRPX05BVklHQVRJT05fREVMQVkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIEF1dG8tbmF2aWdhdGlvbiBpcyBwYXVzZWQsIHNraXBwaW5nIGF1dG8tY2xpY2tcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcImVycm9yXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVVcGxvYWRTdGF0dXNUb2FzdChcImVycm9yXCIsIGDsl4XroZzrk5wg7Iuk7YyoOiAke21lc3NhZ2UuZXJyb3IgfHwgXCLslYwg7IiYIOyXhuuKlCDsmKTrpZhcIn1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZVByb2dyZXNzVG9hc3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufSk7XG4vKipcbiAqIExpc3RlbiBmb3Igc3RvcmFnZSBjaGFuZ2VzIGFuZCB1cGRhdGUgYnV0dG9uIHN0YXRlcyBhY2NvcmRpbmdseVxuICovXG5jaHJvbWUuc3RvcmFnZS5vbkNoYW5nZWQuYWRkTGlzdGVuZXIoKGNoYW5nZXMsIGFyZWFOYW1lKSA9PiB7XG4gICAgaWYgKGFyZWFOYW1lID09PSBcImxvY2FsXCIpIHtcbiAgICAgICAgLy8gQ2hlY2sgaWYgY2FtcGFpZ24gZGF0YSBjaGFuZ2VkXG4gICAgICAgIGlmIChjaGFuZ2VzW1wiZ212X21heF9jYW1wYWlnbl9kYXRhXCJdKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gQ29uZmlndXJhdGlvbiBjaGFuZ2VkLCB1cGRhdGluZyBidXR0b24gc3RhdGVzXCIpO1xuICAgICAgICAgICAgLy8gVXBkYXRlIGFsbCBidXR0b25zIHRoYXQgZGVwZW5kIG9uIGNvbmZpZ3VyYXRpb25cbiAgICAgICAgICAgIHVwZGF0ZU5hdmlnYXRpb25CdXR0b25zKCk7XG4gICAgICAgICAgICB1cGRhdGVDb250cm9sQnV0dG9ucygpO1xuICAgICAgICB9XG4gICAgICAgIC8vIFVwZGF0ZSBwcm9ncmVzcyB3aGVuIHJlbGV2YW50IHN0b3JhZ2Uga2V5cyBjaGFuZ2VcbiAgICAgICAgaWYgKGNoYW5nZXNbXCJnbXZfbWF4X2NhbXBhaWduX2RhdGFcIl0gfHwgY2hhbmdlc1tcImdtdl9tYXhfdXBsb2FkX3N1Y2Nlc3Nfc3RhdHVzXCJdKSB7XG4gICAgICAgICAgICB1cGRhdGVQcm9ncmVzc1RvYXN0KCk7XG4gICAgICAgICAgICAvLyBBdXRvLXBhdXNlIHdoZW4gZXZlcnl0aGluZyBpcyBjb21wbGV0ZWQgb3Igbm8gY2FtcGFpZ25zIGV4aXN0XG4gICAgICAgICAgICBjaGVja0FuZFBhdXNlSWZOb1BlbmRpbmdDYW1wYWlnbnMoKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBVcGRhdGUgZGF0ZSBkaXNwbGF5IHdoZW4gZGF0ZSByYW5nZSBjaGFuZ2VzXG4gICAgICAgIGlmIChjaGFuZ2VzW1wiZ212X21heF9kYXRlX3JhbmdlXCJdKSB7XG4gICAgICAgICAgICB1cGRhdGVEYXRlRGlzcGxheSgpO1xuICAgICAgICB9XG4gICAgfVxufSk7XG4vKipcbiAqIEluaXRpYWxpemUgYXV0by1jbGljayBmdW5jdGlvbmFsaXR5XG4gKiBDaGVja3MgaWYgZmVhdHVyZSBpcyBlbmFibGVkIGluIHN0b3JhZ2UgYmVmb3JlIGF0dGVtcHRpbmdcbiAqL1xuYXN5bmMgZnVuY3Rpb24gaW5pdGlhbGl6ZSgpIHtcbiAgICB0cnkge1xuICAgICAgICAvLyBDaGVjayBpZiB3ZSdyZSBvbiB0aGUgY29ycmVjdCBVUkxcbiAgICAgICAgY29uc3QgdXJsUGF0dGVybiA9IC9hZHNcXC50aWt0b2tcXC5jb21cXC9pMThuXFwvZ212LW1heFxcL2Rhc2hib2FyZC87XG4gICAgICAgIGlmICghdXJsUGF0dGVybi50ZXN0KHdpbmRvdy5sb2NhdGlvbi5ocmVmKSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIE5vdCBvbiBHTVYgTWF4IGRhc2hib2FyZCBwYWdlXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUubG9nKFwiW0dNViBNYXggTmF2aWdhdG9yXSBJbml0aWFsaXppbmcgb24gR01WIE1heCBkYXNoYm9hcmRcIik7XG4gICAgICAgIC8vIFJlc3RvcmUgcGF1c2VkL3Jlc3VtZWQgc3RhdGUgZnJvbSBzdG9yYWdlIChkZWZhdWx0IHRvIHBhdXNlZClcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHN0b3JlZFN0YXRlID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFtXT1JLRkxPV19QQVVTRURfS0VZXSk7XG4gICAgICAgICAgICAvLyBJZiBleHBsaWNpdGx5IHNldCB0byBmYWxzZSwgaXQgbWVhbnMgcmVzdW1lZDsgb3RoZXJ3aXNlIHRyZWF0IGFzIHBhdXNlZCBieSBkZWZhdWx0XG4gICAgICAgICAgICBpc0F1dG9OYXZpZ2F0aW9uUGF1c2VkID0gc3RvcmVkU3RhdGVbV09SS0ZMT1dfUEFVU0VEX0tFWV0gIT09IGZhbHNlO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIFJlc3RvcmVkIHBhdXNlZCBzdGF0ZTpcIiwgaXNBdXRvTmF2aWdhdGlvblBhdXNlZCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcIltHTVYgTWF4IE5hdmlnYXRvcl0gRmFpbGVkIHRvIHJlc3RvcmUgcGF1c2VkIHN0YXRlLCBkZWZhdWx0aW5nIHRvIHBhdXNlZFwiKTtcbiAgICAgICAgICAgIGlzQXV0b05hdmlnYXRpb25QYXVzZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIC8vIEluamVjdCBVSSBlbGVtZW50cyAoYWx3YXlzIHZpc2libGUsIGRpc2FibGVkIGlmIG5vdCBjb25maWd1cmVkKVxuICAgICAgICBhd2FpdCBpbmplY3ROYXZpZ2F0aW9uQnV0dG9ucygpO1xuICAgICAgICBhd2FpdCBpbmplY3RVcGxvYWRTdGF0dXNUb2FzdCgpO1xuICAgICAgICBhd2FpdCBpbmplY3REYXRlRGlzcGxheUJveCgpO1xuICAgICAgICBhd2FpdCBpbmplY3RQcm9ncmVzc1RvYXN0KCk7XG4gICAgICAgIGF3YWl0IGluamVjdENvbnRyb2xCdXR0b25zKCk7XG4gICAgICAgIC8vIEVuc3VyZSBwYXVzZWQgd2hlbiB0aGVyZSBhcmUgbm8gY2FtcGFpZ25zIHRvIHVwbG9hZFxuICAgICAgICBhd2FpdCBjaGVja0FuZFBhdXNlSWZOb1BlbmRpbmdDYW1wYWlnbnMoKTtcbiAgICAgICAgLy8gQ2hlY2sgaWYgYXV0by1jbGljayBpcyBlbmFibGVkXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbU1RPUkFHRV9LRVldKTtcbiAgICAgICAgY29uc3QgaXNFbmFibGVkID0gcmVzdWx0W1NUT1JBR0VfS0VZXSAhPT0gZmFsc2U7IC8vIERlZmF1bHQgdG8gdHJ1ZVxuICAgICAgICBpZiAoIWlzRW5hYmxlZCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIEF1dG8tY2xpY2sgaXMgZGlzYWJsZWRcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIEF1dG8tY2xpY2sgaXMgZW5hYmxlZFwiKTtcbiAgICAgICAgLy8gT25seSBzdGFydCBhdXRvLWNsaWNrIGlmIG5vdCBwYXVzZWRcbiAgICAgICAgaWYgKCFpc0F1dG9OYXZpZ2F0aW9uUGF1c2VkKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIltHTVYgTWF4IE5hdmlnYXRvcl0gU3RhcnRpbmcgYXV0by1jbGljayB3b3JrZmxvd1wiKTtcbiAgICAgICAgICAgIC8vIFN0YXJ0IGF0dGVtcHRpbmcgdG8gY2xpY2sgdGhlIGJ1dHRvblxuICAgICAgICAgICAgYXR0ZW1wdEF1dG9DbGljaygpO1xuICAgICAgICAgICAgLy8gQWxzbyBvYnNlcnZlIGZvciBkeW5hbWljIGNvbnRlbnQgY2hhbmdlc1xuICAgICAgICAgICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigobXV0YXRpb25zKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gQ2hlY2sgaWYgYW55IG11dGF0aW9ucyBhZGRlZCBub2Rlc1xuICAgICAgICAgICAgICAgIGNvbnN0IGhhc05ld05vZGVzID0gbXV0YXRpb25zLnNvbWUobXV0YXRpb24gPT4gbXV0YXRpb24uYWRkZWROb2Rlcy5sZW5ndGggPiAwKTtcbiAgICAgICAgICAgICAgICBpZiAoaGFzTmV3Tm9kZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRGVib3VuY2U6IG9ubHkgY2hlY2sgb25jZSBhZnRlciBjaGFuZ2VzIHNldHRsZVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGlja2VkID0gZmluZEFuZENsaWNrRXhwb3J0QnV0dG9uKCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjbGlja2VkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7IC8vIFN0b3Agb2JzZXJ2aW5nIG9uY2Ugd2UndmUgY2xpY2tlZFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAvLyBPYnNlcnZlIHRoZSBlbnRpcmUgZG9jdW1lbnQgZm9yIGNoYW5nZXNcbiAgICAgICAgICAgIG9ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQuYm9keSwge1xuICAgICAgICAgICAgICAgIGNoaWxkTGlzdDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBzdWJ0cmVlOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAvLyBEaXNjb25uZWN0IG9ic2VydmVyIGFmdGVyIGEgcmVhc29uYWJsZSB0aW1lIHRvIGF2b2lkIG1lbW9yeSBsZWFrc1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBvYnNlcnZlci5kaXNjb25uZWN0KCksIDMwMDAwKTsgLy8gMzAgc2Vjb25kc1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJbR01WIE1heCBOYXZpZ2F0b3JdIEF1dG8tY2xpY2sgd29ya2Zsb3cgaXMgcGF1c2VkLCB3YWl0aW5nIGZvciB1c2VyIHRvIHJlc3VtZVwiKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIltHTVYgTWF4IE5hdmlnYXRvcl0gRXJyb3IgaW4gYXV0by1jbGljayBpbml0aWFsaXphdGlvbjpcIiwgZXJyb3IpO1xuICAgIH1cbn1cbi8vIFJ1biBpbml0aWFsaXphdGlvbiB3aGVuIERPTSBpcyByZWFkeVxuaWYgKGRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwibG9hZGluZ1wiKSB7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIkRPTUNvbnRlbnRMb2FkZWRcIiwgaW5pdGlhbGl6ZSk7XG59XG5lbHNlIHtcbiAgICBpbml0aWFsaXplKCk7XG59XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=